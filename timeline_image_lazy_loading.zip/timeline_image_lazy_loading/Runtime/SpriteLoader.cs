using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

// Called from the Unity main thread; resumes on UnitySynchronizationContext.
public sealed class SpriteLoader : ISpriteLoader
{
    public async Task<Sprite> LoadAsync(
        string absolutePath, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (!File.Exists(absolutePath))
            throw new FileNotFoundException("Image file not found.", absolutePath);

        var uri = new Uri(absolutePath).AbsoluteUri;
        using var request = UnityWebRequestTexture.GetTexture(uri, nonReadable: true);
        var operation = request.SendWebRequest();

        try
        {
            while (!operation.isDone)
            {
                cancellationToken.ThrowIfCancellationRequested();
                await Task.Yield();
            }
            cancellationToken.ThrowIfCancellationRequested();
        }
        catch (OperationCanceledException)
        {
            request.Abort();
            throw;
        }

        if (request.result != UnityWebRequest.Result.Success)
            throw new IOException($"Image load failed: {absolutePath}: {request.error}");

        var texture = DownloadHandlerTexture.GetContent(request);
        if (texture == null)
            throw new InvalidDataException($"Invalid image: {absolutePath}");

        try
        {
            return Sprite.Create(texture,
                new Rect(0f, 0f, texture.width, texture.height),
                new Vector2(0.5f, 0.5f), 100f);
        }
        catch
        {
            UnityEngine.Object.Destroy(texture);
            throw;
        }
    }
}
