using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

// Main-thread-only repository: Unity objects, dictionaries and Dispose are not thread-safe.
// The existing CSV parser supplies the ID -> relative path map to this constructor.
public sealed class ImageRepository : IImageRepository, IDisposable
{
    private readonly ISpriteLoader _loader;
    private readonly string _dataRoot;
    private readonly Dictionary<string, string> _pathsById;
    private readonly Dictionary<string, Sprite> _cache =
        new Dictionary<string, Sprite>(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, Task<Sprite>> _loading =
        new Dictionary<string, Task<Sprite>>(StringComparer.OrdinalIgnoreCase);
    private readonly CancellationTokenSource _shutdown = new CancellationTokenSource();
    private bool _disposed;

    public ImageRepository(
        ISpriteLoader loader,
        string dataRoot,
        IReadOnlyDictionary<string, string> pathsById)
    {
        _loader = loader ?? throw new ArgumentNullException(nameof(loader));
        if (string.IsNullOrWhiteSpace(dataRoot))
            throw new ArgumentException("Data root is required.", nameof(dataRoot));
        _dataRoot = Path.GetFullPath(dataRoot)
            .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
            + Path.DirectorySeparatorChar;

        if (pathsById == null)
            throw new ArgumentNullException(nameof(pathsById));
        _pathsById = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var entry in pathsById)
            _pathsById.Add(entry.Key, entry.Value);
    }

    // Retains the existing eager-load behavior for images in the resource-definition CSV.
    public async Task InitializeAsync(CancellationToken cancellationToken)
    {
        ThrowIfDisposed();
        foreach (var path in _pathsById.Values)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await GetOrLoadByPathAsync(path);
        }
    }

    public Sprite Get(ImageId id)
    {
        ThrowIfDisposed();
        if (id == null)
            throw new ArgumentNullException(nameof(id));
        if (!_pathsById.TryGetValue(id.Value, out var path))
            throw new KeyNotFoundException($"Unknown image ID: {id.Value}");

        var key = ResolvePath(path);
        if (_cache.TryGetValue(key, out var sprite))
            return sprite;
        throw new InvalidOperationException($"Image not initialized: {id.Value}");
    }

    public Task<Sprite> GetOrLoadByPathAsync(string relativePath)
    {
        ThrowIfDisposed();
        var key = ResolvePath(relativePath);
        if (_cache.TryGetValue(key, out var sprite))
            return Task.FromResult(sprite);
        if (_loading.TryGetValue(key, out var pending))
            return pending;

        // Register the task before starting the loader: concurrent callers share it.
        var source = new TaskCompletionSource<Sprite>(
            TaskCreationOptions.RunContinuationsAsynchronously);
        _loading.Add(key, source.Task);
        _ = LoadAndCacheAsync(key, source);
        return source.Task;
    }

    private async Task LoadAndCacheAsync(
        string key, TaskCompletionSource<Sprite> source)
    {
        try
        {
            var sprite = await _loader.LoadAsync(key, _shutdown.Token);
            if (_disposed)
            {
                DestroySprite(sprite);
                throw new OperationCanceledException("Repository has been disposed.");
            }
            _cache.Add(key, sprite);
            source.TrySetResult(sprite);
        }
        catch (Exception error)
        {
            source.TrySetException(error);
        }
        finally
        {
            _loading.Remove(key);
        }
    }

    private string ResolvePath(string relativePath)
    {
        if (string.IsNullOrWhiteSpace(relativePath) ||
            Path.IsPathRooted(relativePath))
            throw new ArgumentException("Expected a Data-relative path.",
                nameof(relativePath));

        var key = Path.GetFullPath(Path.Combine(_dataRoot, relativePath));
        if (!key.StartsWith(_dataRoot, StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Image path is outside the Data directory.",
                nameof(relativePath));
        return key;
    }

    private void ThrowIfDisposed()
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(ImageRepository));
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _shutdown.Cancel();
        foreach (var sprite in _cache.Values)
            DestroySprite(sprite);
        _cache.Clear();
        _shutdown.Dispose();
        // In-flight loaders observe cancellation on their next Unity-frame continuation.
    }

    private static void DestroySprite(Sprite sprite)
    {
        if (sprite == null) return;
        var texture = sprite.texture;
        UnityEngine.Object.Destroy(sprite);
        if (texture != null)
            UnityEngine.Object.Destroy(texture);
    }
}
