# SetImageByPath – Lazy Loading implementation

## Scope

Unity 6 / Windows standalone / C# 9.0 integration reference for the current timeline app.
This archive is **not an automatic patch** of the existing project. The actual
ImageRepository, UiController, Unity namespaces, DI registrations and IDs were not
available as source files; reconcile these snippets with the real implementations.

## Files

- `Runtime/IImageRepository.cs`: public API for ID lookup and path-based on-demand loads.
- `Runtime/ISpriteLoader.cs`: dependency injection boundary.
- `Runtime/SpriteLoader.cs`: file URI -> UnityWebRequestTexture -> Texture2D -> Sprite.
- `Runtime/ImageRepository.cs`: shared cache and one in-flight Task per normalized path.
- `IntegrationExample/IUiImageOutput.cs`: bridge to existing UI rendering code.
- `IntegrationExample/UiImageController.cs`: void timeline commands, latest-request wins.
- `Tests/PlayMode/ImageRepositoryTests.cs`: PlayMode tests for loading deduplication and failure retry.

## Integration steps

1. Keep the existing CSV parser (the **resource definition file**) and pass its
   ImageId.Value -> Data-relative path map as `IReadOnlyDictionary<string,string>`
   to ImageRepository. Reuse any existing serialized resources; do not replace
   your CSV parser with a second one.
2. Provide `dataRoot` as the absolute `Data` folder **beside the .exe**.
   For a Windows build, `Path.GetFullPath(Path.Combine(Application.dataPath, "..", "Data"))`
   is a typical way to construct it. In the Unity Editor, choose a suitable project
   Data root through the Composition Root rather than hardcoding it in the repository.
3. Initialize the repository using `await repository.InitializeAsync(token)` before
   enabling normal/timeline command execution. Resource-definition images remain
   eagerly loaded, as before.
4. Merge the `SetImageByPath` and latest-request tracking methods into the
   existing UI/Image controller. Do not register duplicate `[TimelineCommand("SetImage")]`
   owners. Use the app's UI image target registry in place of `IUiImageOutput`.
5. Register a singleton `ISpriteLoader` and `IImageRepository` in VContainer;
   register the command owner according to the existing lifetime scope.
6. On timeline Stop, Reset, replacement or scene teardown, call
   `InvalidatePending()` on the controller. On image replace/clear via a different
   API, call `InvalidatePending(target)` to avoid stale late results.
7. Regenerate the command definition JSON so the editor recognizes
   `SetImageByPath(target, path)`, using the existing file-path editor metadata.
   The runtime does not need to read the command definition JSON.

## Behavior

- First path request: loads asynchronously; UI remains responsive.
- Concurrent requests for the same path: share the same pending Task.
- Further requests: same Sprite is returned from the cache without an async delay.
- Failed load: **not cached**, so a later request retries.
- Old late results: do not update the target if a newer request was made.
- Cancel/Stop/Reset: invalidates UI updates, but a pending load may finish and
  populate the shared cache; this is intentional.
- When the repository is disposed: cancels pending loader operations and destroys
  cached Sprite and Texture2D objects.

## Important contracts

- All repository and controller methods must be called from Unity's **main thread**.
  Task continuations started on the main thread resume there by default. Do not
  add `ConfigureAwait(false)` around Unity API access.
- Avoid disposing ImageRepository while active UI consumers still rely on its Sprite.
- The displayed image's **first-use timing is not deterministic**: the timeline
  emits a command on time, but its visual result arrives once the file loads.
- The repository rejects absolute paths and `..` traversal beyond Data, but does
  not resolve Windows junctions or symbolic links; restrict use to trusted local
  content unless extra validation is added.
- By design, replacement of an already cached file at the same path is **not**
  noticed until application restart; a dedicated invalidation/reload operation
  must be added if hot replacement is required.
- This sample assumes `ImageId.Value` and `UiTargetId.Value` are strings, and
  that `[TimelineCommand]` is already defined in the existing app.
- Unity PlayMode tests are provided for integration; they have **not been run**
  against the actual project in this environment.

## Tests to add to the existing project

- ID-based and path-based access to the same path return the same Sprite.
- Two UI targets share an in-flight image load.
- Two successive SetImageByPath commands to one UI target do not render the
  older completion over the newer one.
- SetImage, clear-image and timeline reset invalidate old pending results.
- Missing files return errors, are not cached, and can be retried.
- Paths resolving outside Data are rejected.
- New files added after build are loadable without an ID or CSV update.

`Tests/PlayMode/UiImageControllerTests.cs` contains two additional PlayMode tests for
out-of-order asynchronous completion and invalidation during reset. They use
`UiTargetId(string)` in line with the project's value-object convention; adjust
that constructor call if the actual type differs.
