using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

public sealed class ImageRepositoryTests
{
    [UnityTest]
    public IEnumerator DuplicateRequestsShareAnInFlightLoad()
    {
        var loader = new DeferredLoader();
        using var repository = CreateRepository(loader);
        var first = repository.GetOrLoadByPathAsync("Images/test.png");
        var second = repository.GetOrLoadByPathAsync("Images/test.png");

        Assert.AreSame(first, second);
        Assert.AreEqual(1, loader.CallCount);

        loader.Complete(CreateSprite());
        yield return new WaitUntil(() => first.IsCompleted && second.IsCompleted);
        Assert.AreSame(first.Result, second.Result);

        var third = repository.GetOrLoadByPathAsync("Images/test.png");
        Assert.IsTrue(third.IsCompletedSuccessfully);
        Assert.AreSame(first.Result, third.Result);
        Assert.AreEqual(1, loader.CallCount);
    }

    [UnityTest]
    public IEnumerator FailedLoadDoesNotPoisonTheCache()
    {
        var loader = new DeferredLoader();
        using var repository = CreateRepository(loader);
        var first = repository.GetOrLoadByPathAsync("Images/test.png");
        loader.Fail(new IOException("Missing file"));
        yield return new WaitUntil(() => first.IsCompleted);
        Assert.IsTrue(first.IsFaulted);
        _ = first.Exception; // Observe expected failure.

        var retry = repository.GetOrLoadByPathAsync("Images/test.png");
        Assert.AreEqual(2, loader.CallCount);
        loader.Complete(CreateSprite());
        yield return new WaitUntil(() => retry.IsCompleted);
        Assert.IsFalse(retry.IsFaulted);
    }

    private static ImageRepository CreateRepository(ISpriteLoader loader)
    {
        return new ImageRepository(loader, Path.GetTempPath(),
            new Dictionary<string, string>());
    }

    private static Sprite CreateSprite()
    {
        var texture = new Texture2D(2, 2);
        return Sprite.Create(texture, new Rect(0, 0, 2, 2),
            new Vector2(0.5f, 0.5f));
    }

    private sealed class DeferredLoader : ISpriteLoader
    {
        private TaskCompletionSource<Sprite> _pending;
        public int CallCount { get; private set; }

        public Task<Sprite> LoadAsync(string path, CancellationToken token)
        {
            CallCount++;
            _pending = new TaskCompletionSource<Sprite>();
            return _pending.Task;
        }

        public void Complete(Sprite sprite) => _pending.SetResult(sprite);
        public void Fail(Exception exception) => _pending.SetException(exception);
    }
}
