using System;
using System.IO;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(RepositoryIdGenerationConfig))]
public sealed class RepositoryIdGenerationConfigEditor : Editor
{
    public override void OnInspectorGUI()
    {
        serializedObject.Update();
        DrawRepositoryFile();
        EditorGUILayout.PropertyField(serializedObject.FindProperty("idTypeScript"),
            new GUIContent("ID Type (Script)"));
        EditorGUILayout.PropertyField(serializedObject.FindProperty("targetClassScript"),
            new GUIContent("Target Class (Script)"));
        serializedObject.ApplyModifiedProperties();

        EditorGUILayout.Space(12);
        if (GUILayout.Button("Generate ID Class", GUILayout.Height(30)))
            Generate((RepositoryIdGenerationConfig)target);
    }

    private void DrawRepositoryFile()
    {
        var property = serializedObject.FindProperty("repositoryFilePath");
        EditorGUILayout.LabelField("Repository CSV");
        using (new EditorGUILayout.HorizontalScope())
        {
            using (new EditorGUI.DisabledScope(true))
                EditorGUILayout.TextField(property.stringValue);
            if (GUILayout.Button("Browse...", GUILayout.Width(85)))
            {
                var current = property.stringValue;
                var directory = File.Exists(current) ? Path.GetDirectoryName(current) : Application.dataPath;
                var selected = EditorUtility.OpenFilePanel("Select Repository CSV", directory, "csv");
                if (!string.IsNullOrEmpty(selected)) property.stringValue = selected;
            }
        }
    }

    [MenuItem("Tools/Repository/Generate ID Class", true)]
    private static bool CanGenerate() => Selection.activeObject is RepositoryIdGenerationConfig;

    [MenuItem("Tools/Repository/Generate ID Class")]
    private static void GenerateFromMenu() => Generate((RepositoryIdGenerationConfig)Selection.activeObject);

    private static void Generate(RepositoryIdGenerationConfig config)
    {
        try
        {
            var path = RepositoryIdGenerator.Generate(config);
            Debug.Log($"[RepositoryIdGenerator] Generated: {path}");
            EditorUtility.DisplayDialog("ID Class Generated", path, "OK");
        }
        catch (Exception exception)
        {
            Debug.LogException(exception);
            EditorUtility.DisplayDialog("Generation Failed", exception.Message, "OK");
        }
    }
}
