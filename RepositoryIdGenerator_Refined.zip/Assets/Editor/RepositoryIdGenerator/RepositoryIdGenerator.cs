using System;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

public static class RepositoryIdGenerator
{
    public static string Generate(RepositoryIdGenerationConfig config)
    {
        if (config == null) throw new ArgumentNullException(nameof(config));

        var idType = GetClass(config.IdTypeScript, "ID Type");
        var targetType = GetClass(config.TargetClassScript, "Target Class");
        if (targetType.IsNested)
            throw new InvalidOperationException("Target Class must not be nested.");

        var ids = CsvIdReader.ReadIds(config.RepositoryFilePath);
        CSharpIdValidator.Validate(ids, targetType.Name);

        var path = GetOutputPath(config.TargetClassScript, targetType);
        var source = CSharpIdClassWriter.Write(idType, targetType, ids);
        if (Save(path, source)) AssetDatabase.Refresh();
        return path;
    }

    private static Type GetClass(MonoScript script, string label)
    {
        var type = script == null ? null : script.GetClass();
        if (type == null || !type.IsClass || type.ContainsGenericParameters)
            throw new InvalidOperationException($"{label}: select a non-generic C# class script.");
        return type;
    }

    private static string GetOutputPath(MonoScript script, Type type)
    {
        var path = AssetDatabase.GetAssetPath(script);
        if (string.IsNullOrEmpty(path) ||
            !path.StartsWith("Assets/", StringComparison.Ordinal) ||
            !path.EndsWith(".cs", StringComparison.OrdinalIgnoreCase) ||
            path.EndsWith(".g.cs", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Target Class must be a hand-written .cs file inside Assets.");

        var directory = Path.GetDirectoryName(path).Replace('\\', '/');
        return $"{directory}/{type.Name}.g.cs";
    }

    private static bool Save(string assetPath, string source)
    {
        var root = Directory.GetParent(Application.dataPath).FullName;
        var path = Path.Combine(root, assetPath);
        if (File.Exists(path))
        {
            var existing = File.ReadAllText(path);
            if (!existing.StartsWith(CSharpIdClassWriter.Marker, StringComparison.Ordinal))
                throw new IOException($"Refusing to overwrite a non-generated file: {assetPath}");
            if (existing == source) return false;
        }
        File.WriteAllText(path, source, new UTF8Encoding(false));
        return true;
    }
}
