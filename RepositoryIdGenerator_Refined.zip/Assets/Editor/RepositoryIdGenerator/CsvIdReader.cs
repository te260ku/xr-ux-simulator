using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public static class CsvIdReader
{
    public static IReadOnlyList<string> ReadIds(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            throw new FileNotFoundException($"Repository CSV not found: {path}");

        var rows = Parse(File.ReadAllText(path, Encoding.UTF8));
        if (rows.Count == 0) throw new FormatException("Repository CSV is empty.");

        var column = rows[0].FindIndex(value => value.Trim(' ', '\t', '\uFEFF') == "id");
        if (column < 0) throw new FormatException("Repository CSV needs an 'id' column.");

        var ids = new List<string>();
        for (var i = 1; i < rows.Count; i++)
        {
            var row = rows[i];
            if (row.Count == 1 && row[0].Length == 0) continue;
            if (column >= row.Count || row[column].Length == 0)
                throw new FormatException($"CSV row {i + 1} has no ID.");
            ids.Add(row[column]);
        }
        return ids;
    }

    private static List<List<string>> Parse(string text)
    {
        var rows = new List<List<string>>();
        var row = new List<string>();
        var cell = new StringBuilder();
        var quoted = false;
        var quoteClosed = false;

        for (var i = 0; i < text.Length; i++)
        {
            var character = text[i];
            if (quoted)
            {
                if (character == '"' && i + 1 < text.Length && text[i + 1] == '"')
                {
                    cell.Append('"');
                    i++;
                }
                else if (character == '"') { quoted = false; quoteClosed = true; }
                else cell.Append(character);
                continue;
            }

            if (character == '"' && cell.Length == 0 && !quoteClosed)
            {
                quoted = true;
                continue;
            }
            if (character == '"' || (quoteClosed && character != ',' && character != '\r' && character != '\n'))
                throw new FormatException($"Invalid CSV near character {i + 1}.");

            if (character == ',' || character == '\r' || character == '\n')
            {
                row.Add(cell.ToString());
                cell.Clear();
                quoteClosed = false;
                if (character == ',') continue;
                if (character == '\r' && i + 1 < text.Length && text[i + 1] == '\n') i++;
                rows.Add(row);
                row = new List<string>();
            }
            else cell.Append(character);
        }

        if (quoted) throw new FormatException("Unclosed quoted field in CSV.");
        if (cell.Length > 0 || quoteClosed || row.Count > 0)
        {
            row.Add(cell.ToString());
            rows.Add(row);
        }
        return rows;
    }
}
