using UnityEngine;

public enum UiState
{
    Normal,
    Disabled,
    Hidden
}

public sealed class ExampleTimelineCommands
{
    [TimelineCommand("PlaySound")]
    public void PlaySound(
        [TimelineDefaultValue("Warning01")] SoundId soundId,
        [TimelineDefaultValue(0.8f)] float volume)
    {
        Debug.Log(
            $"PlaySound: {soundId.Value}, volume={volume}");
    }

    [TimelineCommand("SetUiState")]
    public void SetUiState(
        [TimelineDefaultValue("MainPanel")] UiTargetId target,
        [TimelineDefaultValue("Normal")] UiState state)
    {
        Debug.Log(
            $"SetUiState: {target.Value}, state={state}");
    }

    [TimelineCommand("LoadExternalFile")]
    public void LoadExternalFile(
        [TimelineFilePath]
        [TimelineNullable]
        string path)
    {
        Debug.Log($"LoadExternalFile: {path}");
    }
}
