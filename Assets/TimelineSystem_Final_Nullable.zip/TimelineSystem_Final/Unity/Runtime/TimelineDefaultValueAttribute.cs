using System;

[AttributeUsage(
    AttributeTargets.Parameter |
    AttributeTargets.Property |
    AttributeTargets.Field,
    AllowMultiple = false,
    Inherited = false)]
public sealed class TimelineDefaultValueAttribute : Attribute
{
    public object Value { get; }

    public TimelineDefaultValueAttribute(string value)
    {
        Value = value;
    }

    public TimelineDefaultValueAttribute(int value)
    {
        Value = value;
    }

    public TimelineDefaultValueAttribute(float value)
    {
        Value = value;
    }

    public TimelineDefaultValueAttribute(bool value)
    {
        Value = value;
    }
}
