using System.Collections.Generic;

namespace ReactiveSystem
{
    public sealed class ReactivePatternData<TConditionData>
    {
        public TConditionData Condition { get; set; }

        public List<TimelineCommandExecution> Executions { get; set; }
            = new List<TimelineCommandExecution>();
    }
}
