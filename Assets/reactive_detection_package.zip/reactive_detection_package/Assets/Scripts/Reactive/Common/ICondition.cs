namespace ReactiveSystem
{
    public interface ICondition<in TState>
    {
        bool Matches(TState state);
    }
}
