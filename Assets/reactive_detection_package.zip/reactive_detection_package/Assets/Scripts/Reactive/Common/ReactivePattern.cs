using System;
using System.Collections.Generic;
using System.Linq;

namespace ReactiveSystem
{
    public sealed class ReactivePattern<TState>
    {
        public ICondition<TState> Condition { get; }
        public IReadOnlyList<TimelineCommandExecution> Executions { get; }

        public ReactivePattern(
            ICondition<TState> condition,
            IEnumerable<TimelineCommandExecution> executions)
        {
            Condition = condition
                ?? throw new ArgumentNullException(nameof(condition));

            Executions = executions?.ToArray()
                ?? throw new ArgumentNullException(nameof(executions));
        }

        public bool Matches(TState state)
        {
            return Condition.Matches(state);
        }
    }
}
