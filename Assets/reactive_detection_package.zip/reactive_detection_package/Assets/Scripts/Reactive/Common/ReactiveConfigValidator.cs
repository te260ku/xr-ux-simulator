using System;

namespace ReactiveSystem
{
    public sealed class ReactiveConfigValidator<TState>
    {
        private readonly TimelineCommandExecutionValidator _executionValidator;

        public ReactiveConfigValidator(
            TimelineCommandExecutionValidator executionValidator)
        {
            _executionValidator = executionValidator
                ?? throw new ArgumentNullException(nameof(executionValidator));
        }

        public void Validate(ReactiveConfig<TState> config)
        {
            if (config == null)
                throw new ArgumentNullException(nameof(config));

            foreach (var pattern in config.Patterns)
                Validate(pattern);
        }

        private void Validate(ReactivePattern<TState> pattern)
        {
            foreach (var execution in pattern.Executions)
                _executionValidator.Validate(execution);
        }
    }
}
