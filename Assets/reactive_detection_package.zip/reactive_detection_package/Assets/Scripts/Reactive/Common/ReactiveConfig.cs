using System;
using System.Collections.Generic;
using System.Linq;

namespace ReactiveSystem
{
    public sealed class ReactiveConfig<TState>
    {
        public const int NoMatch = -1;
        public const int MultipleMatches = -2;

        public IReadOnlyList<ReactivePattern<TState>> Patterns { get; }

        public ReactiveConfig(IEnumerable<ReactivePattern<TState>> patterns)
        {
            Patterns = patterns?.ToArray()
                ?? throw new ArgumentNullException(nameof(patterns));
        }

        public int FindMatchIndex(TState state)
        {
            var matchedIndex = NoMatch;

            for (var i = 0; i < Patterns.Count; i++)
            {
                if (!Patterns[i].Matches(state))
                    continue;

                if (matchedIndex != NoMatch)
                    return MultipleMatches;

                matchedIndex = i;
            }

            return matchedIndex;
        }

        public ReactivePattern<TState> GetPattern(int index)
        {
            if (index < 0 || index >= Patterns.Count)
                throw new ArgumentOutOfRangeException(nameof(index));

            return Patterns[index];
        }
    }
}
