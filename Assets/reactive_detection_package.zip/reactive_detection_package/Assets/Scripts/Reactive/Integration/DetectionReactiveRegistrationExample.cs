using System.IO;
using ReactiveSystem.Detection;
using VContainer;
using VContainer.Unity;

namespace ReactiveSystem.Integration
{
    // Copy the relevant parts into your existing LifetimeScope/CompositionRoot.
    // This file is an integration example, not a second CompositionRoot.
    public sealed class DetectionReactiveRegistrationExample
    {
        private readonly string _configPath;

        public DetectionReactiveRegistrationExample(string configPath)
        {
            _configPath = configPath;
        }

        public void Register(IContainerBuilder builder)
        {
            builder.Register<DetectionModel>(Lifetime.Singleton);
            builder.Register<DetectionReactiveConfigLoader>(Lifetime.Singleton);
            builder.Register<ReactiveConfigValidator<DetectionState>>(Lifetime.Singleton);

            builder.Register<ReactiveConfig<DetectionState>>(
                CreateConfig,
                Lifetime.Singleton);

            builder.RegisterEntryPoint<DetectionReactiveHandler>();
            builder.RegisterEntryPoint<DetectionUpdater>();
        }

        private ReactiveConfig<DetectionState> CreateConfig(
            IObjectResolver resolver)
        {
            var loader = resolver.Resolve<DetectionReactiveConfigLoader>();
            var validator = resolver.Resolve<ReactiveConfigValidator<DetectionState>>();
            var json = File.ReadAllText(_configPath);
            var config = loader.Load(json);

            validator.Validate(config);
            return config;
        }
    }
}
