namespace ReactiveSystem.Detection
{
    public sealed class DetectionConditionData
    {
        public DetectedObject Object { get; set; }
        public float MaxDistance { get; set; }
        public DetectionPosition Position { get; set; }
    }
}
