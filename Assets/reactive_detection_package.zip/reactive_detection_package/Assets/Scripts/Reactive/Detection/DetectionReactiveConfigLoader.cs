using System;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace ReactiveSystem.Detection
{
    public sealed class DetectionReactiveConfigLoader
    {
        private readonly JsonSerializerOptions _options;

        public DetectionReactiveConfigLoader(JsonSerializerOptions options)
        {
            _options = options
                ?? throw new ArgumentNullException(nameof(options));
        }

        public ReactiveConfig<DetectionState> Load(string json)
        {
            if (string.IsNullOrWhiteSpace(json))
                throw new InvalidDataException("Reactive config JSON is empty.");

            var data = Deserialize(json);
            var patterns = data.Patterns.Select(CreatePattern);
            return new ReactiveConfig<DetectionState>(patterns);
        }

        private ReactiveConfigData<DetectionConditionData> Deserialize(
            string json)
        {
            var data = JsonSerializer.Deserialize<
                ReactiveConfigData<DetectionConditionData>>(
                json,
                _options);

            return data ?? throw new InvalidDataException(
                "Detection reactive config is invalid.");
        }

        private ReactivePattern<DetectionState> CreatePattern(
            ReactivePatternData<DetectionConditionData> data)
        {
            if (data == null)
                throw new InvalidDataException("Pattern is null.");

            if (data.Condition == null)
                throw new InvalidDataException("Pattern condition is missing.");

            return new ReactivePattern<DetectionState>(
                CreateCondition(data.Condition),
                data.Executions);
        }

        private static DetectionCondition CreateCondition(
            DetectionConditionData data)
        {
            return new DetectionCondition(
                data.Object,
                data.MaxDistance,
                data.Position);
        }
    }
}
