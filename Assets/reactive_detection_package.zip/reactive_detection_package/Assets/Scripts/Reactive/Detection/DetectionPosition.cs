namespace ReactiveSystem.Detection
{
    public enum DetectionPosition
    {
        None,
        Left,
        Center,
        Right
    }
}
