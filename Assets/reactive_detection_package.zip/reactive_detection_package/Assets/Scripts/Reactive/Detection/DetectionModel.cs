using System;
using R3;

namespace ReactiveSystem.Detection
{
    public sealed class DetectionModel : IDisposable
    {
        private readonly ReactiveProperty<DetectionState> _state;

        public Observable<DetectionState> State => _state;

        public DetectionModel()
        {
            _state = new ReactiveProperty<DetectionState>(CreateInitialState());
        }

        public void Update(DetectionState state)
        {
            _state.Value = state ?? throw new ArgumentNullException(nameof(state));
        }

        public void Dispose()
        {
            _state.Dispose();
        }

        private static DetectionState CreateInitialState()
        {
            return new DetectionState(
                DetectedObject.None,
                0f,
                DetectionPosition.None);
        }
    }
}
