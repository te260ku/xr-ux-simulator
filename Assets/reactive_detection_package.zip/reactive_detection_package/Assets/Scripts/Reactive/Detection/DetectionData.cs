namespace ReactiveSystem.Detection
{
    public sealed class DetectionData
    {
        public DetectedObject Object { get; }
        public float Distance { get; }
        public DetectionPosition Position { get; }

        public DetectionData(
            DetectedObject @object,
            float distance,
            DetectionPosition position)
        {
            Object = @object;
            Distance = distance;
            Position = position;
        }
    }
}
