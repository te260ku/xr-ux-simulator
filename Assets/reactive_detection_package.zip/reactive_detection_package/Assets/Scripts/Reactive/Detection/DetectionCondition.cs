using System;

namespace ReactiveSystem.Detection
{
    public sealed class DetectionCondition : ICondition<DetectionState>
    {
        public DetectedObject Object { get; }
        public float MaxDistance { get; }
        public DetectionPosition Position { get; }

        public DetectionCondition(
            DetectedObject @object,
            float maxDistance,
            DetectionPosition position)
        {
            if (maxDistance < 0f)
                throw new ArgumentOutOfRangeException(nameof(maxDistance));

            Object = @object;
            MaxDistance = maxDistance;
            Position = position;
        }

        public bool Matches(DetectionState state)
        {
            if (state == null)
                throw new ArgumentNullException(nameof(state));

            return state.Object == Object
                && state.Distance <= MaxDistance
                && state.Position == Position;
        }
    }
}
