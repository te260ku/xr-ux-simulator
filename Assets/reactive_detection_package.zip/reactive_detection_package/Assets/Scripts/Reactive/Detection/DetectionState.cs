using System;

namespace ReactiveSystem.Detection
{
    public sealed class DetectionState
    {
        public DetectedObject Object { get; }
        public float Distance { get; }
        public DetectionPosition Position { get; }

        public DetectionState(
            DetectedObject @object,
            float distance,
            DetectionPosition position)
        {
            if (distance < 0f)
                throw new ArgumentOutOfRangeException(nameof(distance));

            Object = @object;
            Distance = distance;
            Position = position;
        }
    }
}
