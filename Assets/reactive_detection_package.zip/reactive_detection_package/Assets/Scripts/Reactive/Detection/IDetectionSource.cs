namespace ReactiveSystem.Detection
{
    public interface IDetectionSource
    {
        DetectionData GetLatest();
    }
}
