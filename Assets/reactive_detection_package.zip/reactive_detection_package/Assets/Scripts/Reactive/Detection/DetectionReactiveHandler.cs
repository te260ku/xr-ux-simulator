using System;
using R3;
using UnityEngine;
using VContainer.Unity;

namespace ReactiveSystem.Detection
{
    public sealed class DetectionReactiveHandler : IStartable, IDisposable
    {
        private readonly DetectionModel _model;
        private readonly ReactiveConfig<DetectionState> _config;
        private readonly TimelineCommandExecutor _executor;
        private readonly CompositeDisposable _disposables
            = new CompositeDisposable();

        public DetectionReactiveHandler(
            DetectionModel model,
            ReactiveConfig<DetectionState> config,
            TimelineCommandExecutor executor)
        {
            _model = model ?? throw new ArgumentNullException(nameof(model));
            _config = config ?? throw new ArgumentNullException(nameof(config));
            _executor = executor ?? throw new ArgumentNullException(nameof(executor));
        }

        public void Start()
        {
            _model.State
                .Select(_config.FindMatchIndex)
                .DistinctUntilChanged()
                .Subscribe(OnPatternChanged)
                .AddTo(_disposables);
        }

        private void OnPatternChanged(int index)
        {
            if (index == ReactiveConfig<DetectionState>.NoMatch)
                return;

            if (index == ReactiveConfig<DetectionState>.MultipleMatches)
            {
                Debug.LogError("Multiple reactive patterns matched.");
                return;
            }

            Execute(_config.GetPattern(index));
        }

        private void Execute(ReactivePattern<DetectionState> pattern)
        {
            foreach (var execution in pattern.Executions)
                _executor.Execute(execution);
        }

        public void Dispose()
        {
            _disposables.Dispose();
        }
    }
}
