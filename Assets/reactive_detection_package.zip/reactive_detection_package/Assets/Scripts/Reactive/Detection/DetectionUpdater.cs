using System;
using VContainer.Unity;

namespace ReactiveSystem.Detection
{
    public sealed class DetectionUpdater : ITickable
    {
        private readonly IDetectionSource _source;
        private readonly DetectionModel _model;

        public DetectionUpdater(
            IDetectionSource source,
            DetectionModel model)
        {
            _source = source ?? throw new ArgumentNullException(nameof(source));
            _model = model ?? throw new ArgumentNullException(nameof(model));
        }

        public void Tick()
        {
            var data = _source.GetLatest();
            _model.Update(CreateState(data));
        }

        private static DetectionState CreateState(DetectionData data)
        {
            if (data == null)
                throw new InvalidOperationException("Detection source returned null.");

            return new DetectionState(
                data.Object,
                data.Distance,
                data.Position);
        }
    }
}
