namespace ReactiveSystem.Detection
{
    public enum DetectedObject
    {
        None,
        Pedestrian,
        Vehicle,
        Bicycle
    }
}
