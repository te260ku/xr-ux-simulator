# Reactive Detection Feature

This package contains the implementation agreed in the design discussion.

## Design

```
C# Library
  -> DetectionUpdater
  -> DetectionModel (ReactiveProperty<DetectionState>)
  -> DetectionReactiveHandler
  -> ReactiveConfig<DetectionState>
  -> ReactivePattern<DetectionState>
  -> TimelineCommandExecution[]
  -> TimelineCommandExecutor
  -> [TimelineCommand] methods
```

The reactive feature does not introduce a second command system. It reuses the existing timeline command execution/validation infrastructure.

## Existing project types expected

The following types are intentionally NOT duplicated in this package:

- `TimelineCommandExecution`
- `TimelineCommandExecutor`
- `TimelineCommandExecutionValidator`
- Existing `[TimelineCommand]` registration/definition system
- Existing `JsonSerializerOptions` used by Timeline JSON
- Existing Sound/Image/Light ID value objects and repositories

Adapt namespaces/usings to the existing project.

## Important behavior

- Each feature has feature-specific `TState` and `ICondition<TState>` implementation.
- `ReactivePattern<TState>` and `ReactiveConfig<TState>` are common.
- Pattern priority is not used.
- 0 matches: execute nothing.
- 1 match: execute its `TimelineCommandExecution[]`.
- 2+ matches: configuration/runtime error; execute nothing.
- `DistinctUntilChanged()` is applied AFTER state -> pattern index conversion.
  Therefore repeated state changes inside the same matched pattern do not repeatedly execute commands.
- `enterExecutions` / `exitExecutions` are intentionally not used. State transitions are represented as normal patterns (for example `Object=None`).

## JSON

`Config/DetectionReactive.sample.json` is illustrative. The `executions` objects must exactly match the Timeline JSON schema already used by the project.

## Integration

`DetectionReactiveRegistrationExample.cs` is only an example of VContainer registration. Copy/adapt it into the existing CompositionRoot instead of adding a second root.

The application-specific C# library adapter should implement:

```csharp
IDetectionSource.GetLatest()
```

and return a `DetectionData` snapshot.
