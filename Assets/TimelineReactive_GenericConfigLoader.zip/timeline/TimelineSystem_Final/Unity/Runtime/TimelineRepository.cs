using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

public sealed class TimelineRepository
{
    private readonly JsonSerializer _serializer;
    private readonly TimelineCommandExecutionFactory _executionFactory;

    private Timeline _current =
        new Timeline(Array.Empty<TimelineEvent>());

    public Timeline Current => _current;

    public TimelineRepository(
        JsonSerializer serializer,
        TimelineCommandExecutionFactory executionFactory)
    {
        _serializer = serializer
            ?? throw new ArgumentNullException(nameof(serializer));

        _executionFactory = executionFactory
            ?? throw new ArgumentNullException(nameof(executionFactory));
    }

    public void Load(TimelineFilePath path)
    {
        if (path == null)
            throw new ArgumentNullException(nameof(path));

        var data = Read(path);
        var events = CreateEvents(data);
        var timeline = new Timeline(events);

        _current = timeline;
    }

    private TimelineEventData[] Read(TimelineFilePath path)
    {
        using var stream = File.OpenText(path.Value);
        using var reader = new JsonTextReader(stream);

        return _serializer.Deserialize<TimelineEventData[]>(reader)
            ?? throw new JsonSerializationException(
                "Timeline could not be deserialized.");
    }

    private TimelineEvent[] CreateEvents(
        IReadOnlyList<TimelineEventData> source)
    {
        var events = new TimelineEvent[source.Count];

        for (var i = 0; i < source.Count; i++)
            events[i] = CreateEvent(source[i]);

        return events;
    }

    private TimelineEvent CreateEvent(TimelineEventData data)
    {
        if (data == null)
            throw new JsonSerializationException(
                "Timeline event must not be null.");

        var time = new TimelineTime(data.Time);
        var execution = _executionFactory.Create(data.Execution);

        return new TimelineEvent(time, execution);
    }
}
