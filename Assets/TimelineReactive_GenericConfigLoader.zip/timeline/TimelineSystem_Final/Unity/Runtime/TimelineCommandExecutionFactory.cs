using System;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public sealed class TimelineCommandExecutionFactory
{
    private readonly TimelineCommandRegistry _commands;
    private readonly JsonSerializer _serializer;

    public TimelineCommandExecutionFactory(
        TimelineCommandRegistry commands,
        JsonSerializer serializer)
    {
        _commands = commands
            ?? throw new ArgumentNullException(nameof(commands));

        _serializer = serializer
            ?? throw new ArgumentNullException(nameof(serializer));
    }

    public TimelineCommandExecution Create(
        TimelineExecutionData data)
    {
        if (data == null)
            throw new JsonSerializationException(
                "Execution must not be null.");

        var id = new TimelineCommandId(data.Command);
        var command = _commands.Get(id);
        var arguments = DeserializeArguments(
            data.Arguments,
            command.Parameters);

        return new TimelineCommandExecution(
            command,
            arguments);
    }

    private object[] DeserializeArguments(
        JObject source,
        IReadOnlyList<ParameterInfo> parameters)
    {
        if (source == null)
            throw new JsonSerializationException(
                "Arguments must not be null.");

        var values = new object[parameters.Count];

        for (var i = 0; i < parameters.Count; i++)
            values[i] = DeserializeArgument(source, parameters[i]);

        EnsureNoUnknownArguments(source, parameters);
        return values;
    }

    private object DeserializeArgument(
        JObject source,
        ParameterInfo parameter)
    {
        var name = parameter.Name
            ?? throw new InvalidOperationException(
                "Timeline command parameter has no name.");

        if (!source.TryGetValue(
                name,
                StringComparison.Ordinal,
                out var token))
        {
            throw new JsonSerializationException(
                $"Argument '{name}' is missing.");
        }

        if (token.Type == JTokenType.Null)
            throw new JsonSerializationException(
                $"Argument '{name}' must not be null.");

        if (parameter.ParameterType ==
            typeof(TimelineCommandExecution))
        {
            return CreateNestedExecution(token);
        }

        return token.ToObject(
                   parameter.ParameterType,
                   _serializer)
               ?? throw new JsonSerializationException(
                   $"Argument '{name}' could not be deserialized.");
    }

    private TimelineCommandExecution CreateNestedExecution(
        JToken token)
    {
        var data = token.ToObject<TimelineExecutionData>(
            _serializer);

        return Create(
            data ?? throw new JsonSerializationException(
                "Execution could not be deserialized."));
    }

    private void EnsureNoUnknownArguments(
        JObject source,
        IReadOnlyList<ParameterInfo> parameters)
    {
        foreach (var property in source.Properties())
        {
            if (!ContainsParameter(parameters, property.Name))
            {
                throw new JsonSerializationException(
                    $"Unknown argument '{property.Name}'.");
            }
        }
    }

    private static bool ContainsParameter(
        IReadOnlyList<ParameterInfo> parameters,
        string name)
    {
        foreach (var parameter in parameters)
        {
            if (string.Equals(
                    parameter.Name,
                    name,
                    StringComparison.Ordinal))
            {
                return true;
            }
        }

        return false;
    }
}
