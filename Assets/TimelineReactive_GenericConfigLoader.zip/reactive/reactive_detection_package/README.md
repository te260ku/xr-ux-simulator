# Reactive Detection Feature

This package keeps the existing Reactive design and shares only the command-execution creation infrastructure with Timeline.

## Design

```text
C# Library
  -> DetectionUpdater
  -> DetectionModel (ReactiveProperty<DetectionState>)
  -> DetectionReactiveHandler
  -> ReactiveConfig<DetectionState>
  -> ReactivePattern<DetectionState>
  -> TimelineCommandExecution[]
  -> TimelineCommandExecution.Execute()
  -> [TimelineCommand] methods
```

Reactive does **not** depend on `TimelineRepository`.

Both Timeline and Reactive use the same `TimelineCommandExecutionFactory`.

## Shared Reactive config loader

Feature-specific loaders are not created.

```text
ReactiveConfigLoader<TState, TConditionData>
        |                    |
        |                    +-- feature-specific ConditionData
        +-- shared JSON / pattern / execution loading
```

A feature supplies only:

- its feature ID
- `TState`
- `TConditionData`
- the conversion from `TConditionData` to `ICondition<TState>`

Detection uses `DetectionCondition.Create` for that conversion.

## Config files

Use one JSON file per feature. The root `feature` field is checked when loading so that a config for the wrong feature fails immediately.

```json
{
  "feature": "Detection",
  "patterns": []
}
```

Each item in `executions` uses exactly the same runtime JSON shape as Timeline:

```json
{
  "command": "PlaySound",
  "arguments": {}
}
```

There is no `"type": "execution"` property in runtime scenario JSON.

## Existing project types reused

- `TimelineExecutionData`
- `TimelineCommandExecution`
- `TimelineCommandExecutionFactory`
- existing `[TimelineCommand]` system
- the same Json.NET `JsonSerializer` instance/settings as Timeline

## Reactive behavior retained

- Feature-specific `TState` and `ICondition<TState>`.
- Common `ReactivePattern<TState>` and `ReactiveConfig<TState>`.
- No priority.
- 0 matches: execute nothing.
- 1 match: execute its executions.
- 2+ matches: report ambiguity and execute nothing.
- `DistinctUntilChanged()` is applied after state -> pattern index conversion.
- No enter/exit execution mechanism.
