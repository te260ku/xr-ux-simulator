using System;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace ReactiveSystem
{
    public sealed class ReactiveConfigLoader<TState, TConditionData>
        where TConditionData : class
    {
        private readonly JsonSerializer _serializer;
        private readonly TimelineCommandExecutionFactory _executionFactory;
        private readonly string _featureId;
        private readonly Func<TConditionData, ICondition<TState>> _createCondition;

        public ReactiveConfigLoader(
            JsonSerializer serializer,
            TimelineCommandExecutionFactory executionFactory,
            string featureId,
            Func<TConditionData, ICondition<TState>> createCondition)
        {
            _serializer = serializer
                ?? throw new ArgumentNullException(nameof(serializer));
            _executionFactory = executionFactory
                ?? throw new ArgumentNullException(nameof(executionFactory));
            _featureId = RequireFeatureId(featureId);
            _createCondition = createCondition
                ?? throw new ArgumentNullException(nameof(createCondition));
        }

        public ReactiveConfig<TState> Load(string json)
        {
            if (string.IsNullOrWhiteSpace(json))
                throw new InvalidDataException("Reactive config JSON is empty.");

            var data = Deserialize(json);
            EnsureFeature(data.Feature);
            return new ReactiveConfig<TState>(data.Patterns.Select(CreatePattern));
        }

        private ReactiveConfigData<TConditionData> Deserialize(string json)
        {
            using var textReader = new StringReader(json);
            using var jsonReader = new JsonTextReader(textReader);
            return _serializer.Deserialize<ReactiveConfigData<TConditionData>>(jsonReader)
                ?? throw new InvalidDataException("Reactive config is invalid.");
        }

        private ReactivePattern<TState> CreatePattern(
            ReactivePatternData<TConditionData> data)
        {
            if (data?.Condition == null)
                throw new InvalidDataException("Pattern condition is missing.");

            var executions = (data.Executions
                ?? throw new InvalidDataException("Pattern executions are missing."))
                .Select(_executionFactory.Create);

            return new ReactivePattern<TState>(
                _createCondition(data.Condition),
                executions);
        }

        private void EnsureFeature(string actual)
        {
            if (string.Equals(actual, _featureId, StringComparison.Ordinal))
                return;

            throw new InvalidDataException(
                $"Expected feature '{_featureId}', but '{actual}' was loaded.");
        }

        private static string RequireFeatureId(string featureId)
        {
            if (string.IsNullOrWhiteSpace(featureId))
                throw new ArgumentException("Feature ID is required.", nameof(featureId));
            return featureId;
        }
    }
}
