using System.Collections.Generic;

namespace ReactiveSystem
{
    public sealed class ReactiveConfigData<TConditionData>
    {
        public string Feature { get; set; }

        public List<ReactivePatternData<TConditionData>> Patterns { get; set; }
            = new List<ReactivePatternData<TConditionData>>();
    }
}
