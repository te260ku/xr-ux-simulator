using System.Collections.Generic;

namespace ReactiveSystem
{
    public sealed class ReactivePatternData<TConditionData>
    {
        public TConditionData Condition { get; set; }

        public List<TimelineExecutionData> Executions { get; set; }
            = new List<TimelineExecutionData>();
    }
}
