using System.IO;
using Newtonsoft.Json;
using ReactiveSystem.Detection;
using VContainer;
using VContainer.Unity;

namespace ReactiveSystem.Integration
{
    // Copy the relevant parts into your existing LifetimeScope/CompositionRoot.
    // JsonSerializer and TimelineCommandExecutionFactory are shared with Timeline.
    public sealed class DetectionReactiveRegistrationExample
    {
        private const string FeatureId = "Detection";
        private readonly string _configPath;

        public DetectionReactiveRegistrationExample(string configPath)
        {
            _configPath = configPath;
        }

        public void Register(IContainerBuilder builder)
        {
            builder.Register<DetectionModel>(Lifetime.Singleton);
            builder.Register<ReactiveConfig<DetectionState>>(
                CreateConfig,
                Lifetime.Singleton);
            builder.RegisterEntryPoint<DetectionReactiveHandler>();
            builder.RegisterEntryPoint<DetectionUpdater>();
        }

        private ReactiveConfig<DetectionState> CreateConfig(
            IObjectResolver resolver)
        {
            var loader = new ReactiveConfigLoader<
                DetectionState,
                DetectionConditionData>(
                resolver.Resolve<JsonSerializer>(),
                resolver.Resolve<TimelineCommandExecutionFactory>(),
                FeatureId,
                DetectionCondition.Create);

            return loader.Load(File.ReadAllText(_configPath));
        }
    }
}
