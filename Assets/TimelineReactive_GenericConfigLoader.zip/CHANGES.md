# Changes

## Shared ReactiveConfigLoader

- Removed feature-specific `DetectionReactiveConfigLoader`.
- Added `ReactiveConfigLoader<TState, TConditionData>` under Reactive/Common.
- The generic loader handles JSON deserialization, feature-ID verification, pattern construction, and `TimelineExecutionData -> TimelineCommandExecution` conversion through the shared `TimelineCommandExecutionFactory`.
- Detection now supplies only `DetectionCondition.Create` as the feature-specific condition conversion.
- Added root `feature` to `ReactiveConfigData<TConditionData>` and `DetectionReactive.sample.json`.
- Reactive still has no dependency on `TimelineRepository`.
- Timeline runtime behavior and JSON format remain unchanged.
