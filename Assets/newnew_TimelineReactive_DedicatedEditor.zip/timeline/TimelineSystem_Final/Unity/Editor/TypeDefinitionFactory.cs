using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json.Serialization;

public sealed class TypeDefinitionFactory
{
    private readonly IContractResolver _contractResolver;

    public TypeDefinitionFactory(IContractResolver contractResolver)
    {
        _contractResolver = contractResolver
            ?? throw new ArgumentNullException(nameof(contractResolver));
    }

    public ParameterDefinition CreateCommandParameter(ParameterInfo parameter)
    {
        if (parameter == null)
            throw new ArgumentNullException(nameof(parameter));

        var name = parameter.Name
            ?? throw new InvalidOperationException(
                "Timeline command parameter has no name.");

        return Create(name, parameter.ParameterType, true);
    }

    public ParameterDefinition Create(string name, Type type)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Definition name is required.", nameof(name));
        if (type == null)
            throw new ArgumentNullException(nameof(type));

        return Create(name, type, false);
    }

    private ParameterDefinition Create(
        string name,
        Type type,
        bool isCommandParameter)
    {
        return CreateTypeDefinition(
            name,
            type,
            new HashSet<Type>(),
            isCommandParameter);
    }

    private ParameterDefinition CreateTypeDefinition(
        string name,
        Type type,
        HashSet<Type> ancestors,
        bool isCommandParameter)
    {
        if (type == typeof(TimelineCommandExecution))
            return CreateExecutionDefinition(name, isCommandParameter);
        if (type.IsEnum)
            return CreateEnumDefinition(name, type);
        if (TryGetScalarType(type, out var scalarType))
            return CreateScalarDefinition(name, scalarType);

        return CreateObjectDefinition(name, type, ancestors);
    }

    private ParameterDefinition CreateExecutionDefinition(
        string name,
        bool isCommandParameter)
    {
        if (!isCommandParameter)
        {
            throw new NotSupportedException(
                "Execution must be a direct command parameter.");
        }

        return new ParameterDefinition
        {
            Name = name,
            Type = "execution"
        };
    }

    private ParameterDefinition CreateEnumDefinition(string name, Type type)
    {
        return new ParameterDefinition
        {
            Name = name,
            Type = "enum",
            Options = Enum.GetNames(type),
            MultiSelect = type.IsDefined(typeof(FlagsAttribute), false)
        };
    }

    private ParameterDefinition CreateScalarDefinition(
        string name,
        string type)
    {
        return new ParameterDefinition
        {
            Name = name,
            Type = type
        };
    }

    private ParameterDefinition CreateObjectDefinition(
        string name,
        Type type,
        HashSet<Type> ancestors)
    {
        EnsureNotRecursive(type, ancestors);

        var contract = _contractResolver.ResolveContract(type);
        if (!(contract is JsonObjectContract objectContract))
        {
            throw new NotSupportedException(
                $"Definition type '{type}' is not supported.");
        }

        var nextAncestors = new HashSet<Type>(ancestors) { type };
        var properties = CreateProperties(objectContract, nextAncestors);
        var source = GetRepositorySource(type);
        EnsureRepositorySourceShape(type, source, properties);

        return new ParameterDefinition
        {
            Name = name,
            Type = "object",
            Source = source,
            Properties = properties
        };
    }

    private ParameterDefinition[] CreateProperties(
        JsonObjectContract contract,
        HashSet<Type> ancestors)
    {
        return contract.Properties
            .Where(property => !property.Ignored)
            .Select(property => CreateProperty(property, ancestors))
            .ToArray();
    }

    private ParameterDefinition CreateProperty(
        JsonProperty property,
        HashSet<Type> ancestors)
    {
        var name = property.PropertyName
            ?? throw new InvalidOperationException("JSON property has no name.");
        var type = property.PropertyType
            ?? throw new InvalidOperationException(
                $"JSON property '{name}' has no type.");

        return CreateTypeDefinition(name, type, ancestors, false);
    }

    private string GetRepositorySource(Type type)
    {
        return type.GetCustomAttribute<RepositoryKeySourceAttribute>()?.Source;
    }

    private bool TryGetScalarType(Type type, out string definitionType)
    {
        if (type == typeof(string)) definitionType = "string";
        else if (type == typeof(int)) definitionType = "int";
        else if (type == typeof(float)) definitionType = "float";
        else if (type == typeof(double)) definitionType = "double";
        else if (type == typeof(bool)) definitionType = "bool";
        else
        {
            definitionType = null;
            return false;
        }

        return true;
    }

    private void EnsureRepositorySourceShape(
        Type type,
        string source,
        ParameterDefinition[] properties)
    {
        if (source == null)
            return;
        if (properties.Length == 1 && properties[0].Type == "string")
            return;

        throw new NotSupportedException(
            $"Repository key type '{type.Name}' must expose " +
            "exactly one string JSON property.");
    }

    private void EnsureNotRecursive(Type type, HashSet<Type> ancestors)
    {
        if (!ancestors.Contains(type))
            return;

        throw new NotSupportedException(
            $"Recursive definition type '{type.Name}' is not supported.");
    }
}
