using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using UnityEditor;
using UnityEngine;

public static class TimelineCommandDefinitionMenu
{
    [MenuItem("Tools/Timeline/Export Command Definitions")]
    private static void Export()
    {
        var path = EditorUtility.SaveFilePanel(
            "Export Timeline Command Definitions",
            "",
            "command-definitions.json",
            "json");

        if (string.IsNullOrWhiteSpace(path))
            return;

        var resolver = new CamelCasePropertyNamesContractResolver();
        var typeFactory = new TypeDefinitionFactory(resolver);
        var exporter = new TimelineCommandDefinitionExporter(
            new TimelineCommandScanner(),
            typeFactory);

        var settings = CreateSettings(resolver);
        var json = JsonConvert.SerializeObject(
            exporter.CreateDefinitions(),
            settings);

        File.WriteAllText(path, json);
        Debug.Log($"Timeline command definitions exported: {path}");
    }

    private static JsonSerializerSettings CreateSettings(
        IContractResolver resolver)
    {
        return new JsonSerializerSettings
        {
            ContractResolver = resolver,
            NullValueHandling = NullValueHandling.Ignore,
            Formatting = Formatting.Indented
        };
    }
}
