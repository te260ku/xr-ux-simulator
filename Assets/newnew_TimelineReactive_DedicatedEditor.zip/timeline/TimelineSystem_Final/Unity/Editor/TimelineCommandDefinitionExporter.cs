using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

public sealed class TimelineCommandDefinitionExporter
{
    private readonly TimelineCommandScanner _scanner;
    private readonly TypeDefinitionFactory _typeDefinitionFactory;

    public TimelineCommandDefinitionExporter(
        TimelineCommandScanner scanner,
        TypeDefinitionFactory typeDefinitionFactory)
    {
        _scanner = scanner
            ?? throw new ArgumentNullException(nameof(scanner));
        _typeDefinitionFactory = typeDefinitionFactory
            ?? throw new ArgumentNullException(nameof(typeDefinitionFactory));
    }

    public CommandDefinitionDocument CreateDefinitions()
    {
        var commands = _scanner.Scan()
            .Select(CreateCommandDefinition)
            .OrderBy(command => command.Id, StringComparer.Ordinal)
            .ToArray();

        EnsureUniqueCommandIds(commands);

        return new CommandDefinitionDocument
        {
            Commands = commands
        };
    }

    private CommandDefinition CreateCommandDefinition(MethodInfo method)
    {
        EnsureCommandMethodIsSupported(method);

        var attribute =
            method.GetCustomAttribute<TimelineCommandAttribute>();
        if (attribute == null)
        {
            throw new InvalidOperationException(
                "TimelineCommandAttribute is required.");
        }

        var id = new TimelineCommandId(attribute.Id);

        return new CommandDefinition
        {
            Id = id.Value,
            Parameters = method.GetParameters()
                .Select(_typeDefinitionFactory.CreateCommandParameter)
                .ToArray()
        };
    }

    private void EnsureUniqueCommandIds(
        IReadOnlyList<CommandDefinition> commands)
    {
        var duplicate = commands
            .GroupBy(command => command.Id, StringComparer.Ordinal)
            .FirstOrDefault(group => group.Count() > 1);

        if (duplicate == null)
            return;

        throw new InvalidOperationException(
            $"Timeline command '{duplicate.Key}' is duplicated.");
    }

    private void EnsureCommandMethodIsSupported(MethodInfo method)
    {
        if (!method.IsPublic || method.IsStatic)
        {
            throw new InvalidOperationException(
                $"{method.DeclaringType?.Name}.{method.Name} must " +
                "be a public instance method.");
        }

        if (method.ReturnType != typeof(void))
        {
            throw new InvalidOperationException(
                $"{method.DeclaringType?.Name}.{method.Name} must return void.");
        }

        if (method.ContainsGenericParameters)
        {
            throw new InvalidOperationException(
                "Generic timeline commands are not supported.");
        }

        foreach (var parameter in method.GetParameters())
            EnsureParameterIsSupported(method, parameter);
    }

    private void EnsureParameterIsSupported(
        MethodInfo method,
        ParameterInfo parameter)
    {
        if (!parameter.IsOut &&
            !parameter.ParameterType.IsByRef &&
            !parameter.IsOptional)
        {
            return;
        }

        throw new InvalidOperationException(
            $"Unsupported parameter '{parameter.Name}' " +
            $"in command '{method.Name}'.");
    }
}
