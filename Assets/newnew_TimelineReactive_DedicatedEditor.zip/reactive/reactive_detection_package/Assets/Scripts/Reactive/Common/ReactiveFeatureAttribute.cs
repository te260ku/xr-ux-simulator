using System;

namespace ReactiveSystem
{
    [AttributeUsage(
        AttributeTargets.Class,
        AllowMultiple = false,
        Inherited = false)]
    public sealed class ReactiveFeatureAttribute : Attribute
    {
        public string Id { get; }

        public ReactiveFeatureAttribute(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
                throw new ArgumentException("Feature ID is required.", nameof(id));

            Id = id;
        }
    }
}
