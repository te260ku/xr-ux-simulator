namespace ReactiveSystem.Editor
{
    public sealed class ReactiveFeatureDefinitionDocument
    {
        public ReactiveFeatureDefinition[] Features { get; set; }
    }

    public sealed class ReactiveFeatureDefinition
    {
        public string Id { get; set; }
        public ParameterDefinition Condition { get; set; }
    }
}
