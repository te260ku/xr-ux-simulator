using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace ReactiveSystem.Editor
{
    public sealed class ReactiveFeatureScanner
    {
        public IReadOnlyList<Type> Scan()
        {
            return AppDomain.CurrentDomain
                .GetAssemblies()
                .SelectMany(GetTypes)
                .Where(HasReactiveFeatureAttribute)
                .ToArray();
        }

        private IEnumerable<Type> GetTypes(Assembly assembly)
        {
            try
            {
                return assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException exception)
            {
                return exception.Types
                    .Where(type => type != null)
                    .Cast<Type>();
            }
        }

        private bool HasReactiveFeatureAttribute(Type type)
        {
            return type.IsDefined(typeof(ReactiveFeatureAttribute), false);
        }
    }
}
