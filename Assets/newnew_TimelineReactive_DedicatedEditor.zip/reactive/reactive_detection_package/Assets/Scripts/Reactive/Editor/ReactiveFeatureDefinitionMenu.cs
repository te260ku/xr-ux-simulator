using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using UnityEditor;
using UnityEngine;

namespace ReactiveSystem.Editor
{
    public static class ReactiveFeatureDefinitionMenu
    {
        [MenuItem("Tools/Reactive/Export Feature Definitions")]
        private static void Export()
        {
            var path = EditorUtility.SaveFilePanel(
                "Export Reactive Feature Definitions",
                "",
                "reactive-feature-definitions.json",
                "json");

            if (string.IsNullOrWhiteSpace(path))
                return;

            var resolver = new CamelCasePropertyNamesContractResolver();
            var typeFactory = new TypeDefinitionFactory(resolver);
            var exporter = new ReactiveFeatureDefinitionExporter(
                new ReactiveFeatureScanner(),
                typeFactory);

            var settings = CreateSettings(resolver);
            var json = JsonConvert.SerializeObject(
                exporter.CreateDefinitions(),
                settings);

            File.WriteAllText(path, json);
            Debug.Log($"Reactive feature definitions exported: {path}");
        }

        private static JsonSerializerSettings CreateSettings(
            IContractResolver resolver)
        {
            return new JsonSerializerSettings
            {
                ContractResolver = resolver,
                NullValueHandling = NullValueHandling.Ignore,
                Formatting = Formatting.Indented
            };
        }
    }
}
