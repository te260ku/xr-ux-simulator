using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace ReactiveSystem.Editor
{
    public sealed class ReactiveFeatureDefinitionExporter
    {
        private readonly ReactiveFeatureScanner _scanner;
        private readonly TypeDefinitionFactory _typeDefinitionFactory;

        public ReactiveFeatureDefinitionExporter(
            ReactiveFeatureScanner scanner,
            TypeDefinitionFactory typeDefinitionFactory)
        {
            _scanner = scanner
                ?? throw new ArgumentNullException(nameof(scanner));
            _typeDefinitionFactory = typeDefinitionFactory
                ?? throw new ArgumentNullException(nameof(typeDefinitionFactory));
        }

        public ReactiveFeatureDefinitionDocument CreateDefinitions()
        {
            var features = _scanner.Scan()
                .Select(CreateDefinition)
                .OrderBy(feature => feature.Id, StringComparer.Ordinal)
                .ToArray();

            EnsureUniqueFeatureIds(features);

            return new ReactiveFeatureDefinitionDocument
            {
                Features = features
            };
        }

        private ReactiveFeatureDefinition CreateDefinition(Type type)
        {
            var attribute = type.GetCustomAttribute<ReactiveFeatureAttribute>()
                ?? throw new InvalidOperationException(
                    "ReactiveFeatureAttribute is required.");

            var condition = _typeDefinitionFactory.Create("condition", type);
            EnsureConditionSupported(condition);

            return new ReactiveFeatureDefinition
            {
                Id = attribute.Id,
                Condition = condition
            };
        }

        private void EnsureConditionSupported(ParameterDefinition definition)
        {
            if (!string.IsNullOrEmpty(definition.Source))
            {
                throw new NotSupportedException(
                    $"Repository source is not supported in condition " +
                    $"'{definition.Name}'.");
            }

            if (definition.Type == "execution")
            {
                throw new NotSupportedException(
                    $"Execution is not supported in condition " +
                    $"'{definition.Name}'.");
            }

            foreach (var property in
                definition.Properties ?? Array.Empty<ParameterDefinition>())
            {
                EnsureConditionSupported(property);
            }
        }

        private void EnsureUniqueFeatureIds(
            IReadOnlyList<ReactiveFeatureDefinition> features)
        {
            var duplicate = features
                .GroupBy(feature => feature.Id, StringComparer.Ordinal)
                .FirstOrDefault(group => group.Count() > 1);

            if (duplicate == null)
                return;

            throw new InvalidOperationException(
                $"Reactive feature '{duplicate.Key}' is duplicated.");
        }
    }
}
