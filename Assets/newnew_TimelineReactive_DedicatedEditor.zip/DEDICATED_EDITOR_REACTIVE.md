# Dedicated Editor Reactive Support

## Overview

The existing Timeline editor now supports Reactive configuration without introducing a second command editor.

Tabs:

- Timeline
- Reactive
- Repository tabs derived from Command Definitions
- Command Definitions
- Reactive Definitions

## Required definition files

Load these files before editing Reactive configuration:

1. `command-definitions.json`
2. `reactive-feature-definitions.json`

The Reactive tab uses the same Command Definition data, argument controls, Repository dropdowns, nested execution handling, validation, and execution JSON builder as Timeline.

## Reactive JSON

One file represents one feature.

```json
{
  "feature": "Detection",
  "patterns": [
    {
      "condition": {},
      "executions": []
    }
  ]
}
```

`executions` uses exactly the same JSON structure as Timeline `execution`.

## Condition editor

The Condition UI is generated recursively from `reactive-feature-definitions.json`.

Supported leaf types:

- string
- int
- float
- double
- bool
- enum

Nested object definitions are rendered recursively. Repository sources and execution fields are rejected for Reactive Conditions.

## Repository references

Repository ID reference counting, rename propagation, and delete clearing now include both:

- Timeline executions
- Reactive executions

Condition fields do not participate because Repository IDs are not supported in Conditions.

## Validation

Reactive validation checks:

- Condition value shape and enum values
- Command existence
- Command arguments
- Repository IDs
- Nested command executions

An empty `executions` array is valid for a Pattern.
