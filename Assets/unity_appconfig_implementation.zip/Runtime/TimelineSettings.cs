using Newtonsoft.Json;

public sealed class TimelineSettings
{
    [JsonProperty("autoPlay")]
    public bool AutoPlay { get; private set; } = false;
}
