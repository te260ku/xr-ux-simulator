using Newtonsoft.Json;

public sealed class ImageSettings
{
    [JsonProperty("maxVisibleCount")]
    public int MaxVisibleCount { get; private set; } = 3;
}
