using System;
using System.IO;
using System.Security;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;

public sealed class AppConfigLoader
{
    public AppConfig LoadOrDefault(string path, Action<string> logError)
    {
        if (logError == null)
            throw new ArgumentNullException(nameof(logError));

        try
        {
            return Load(path, logError);
        }
        catch (Exception ex) when (IsLoadError(ex))
        {
            logError($"AppConfig load failed ({path}). Using defaults.\n{ex}");
            return new AppConfig();
        }
    }

    private static AppConfig Load(string path, Action<string> logError)
    {
        // First parse the entire document: a syntax error must discard all values.
        var root = JObject.Parse(File.ReadAllText(path));
        var config = new AppConfig();
        var serializer = CreateSerializer(logError);

        using (var reader = root.CreateReader())
            serializer.Populate(reader, config);

        return config;
    }

    private static JsonSerializer CreateSerializer(Action<string> logError)
    {
        return JsonSerializer.Create(new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Error,
            Error = (sender, args) => HandleError(args, logError)
        });
    }

    private static void HandleError(ErrorEventArgs args, Action<string> logError)
    {
        var path = args.ErrorContext.Path;
        logError($"AppConfig item ignored ({path}): {args.ErrorContext.Error.Message}");
        args.ErrorContext.Handled = true;
    }

    private static bool IsLoadError(Exception ex)
    {
        return ex is IOException
            || ex is UnauthorizedAccessException
            || ex is SecurityException
            || ex is JsonException;
    }
}
