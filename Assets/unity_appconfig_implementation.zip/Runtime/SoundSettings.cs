using Newtonsoft.Json;

public sealed class SoundSettings
{
    [JsonProperty("volumeScale")]
    public float VolumeScale { get; private set; } = 1.0f;
}
