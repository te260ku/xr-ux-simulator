using Newtonsoft.Json;

public sealed class AppConfig
{
    [JsonProperty("sound")]
    public SoundSettings Sound { get; private set; } = new SoundSettings();

    [JsonProperty("image")]
    public ImageSettings Image { get; private set; } = new ImageSettings();

    [JsonProperty("timeline")]
    public TimelineSettings Timeline { get; private set; } = new TimelineSettings();
}
