# Unity 設定機能（項目単位フォールバック）

## 対象

Unity 6 / Windows Player / VContainer / Newtonsoft.Json（Unityの `com.unity.nuget.newtonsoft-json` など）。

- `Assets/StreamingAssets/appconfig.json` は起動時に1回だけ読み込む。
- `AppLifetimeScope.Configure()` で **既存ログライブラリの初期化を先に実行** してから `AppConfigLoader.LoadOrDefault()` を呼ぶ。
- `AppInitializer : IStartable` はこれまでどおり `RegisterEntryPoint<AppInitializer>()` で登録し、設定の読み込みは移さない。
- 設定値は機能別 `Settings` として `RegisterInstance()` で登録する。
- `dataDirectoryPath` は設定項目に含めない。Windowsビルドのexe同階層に固定の `Data` フォルダを置く。

## ファイル配置

- `Runtime/*.cs` → 既存のScriptsフォルダにコピー
- `StreamingAssets/appconfig.json` → `Assets/StreamingAssets/appconfig.json` にコピー
- `Tests/Editor/AppConfigLoaderTests.cs` → 既存のEditModeテストアセンブリ内へ配置。asmdefを使うプロジェクトでは適切な参照（Newtonsoft.Json、NUnit、テスト対象アセンブリ）を追加する。
- `Integration/AppLifetimeScope.integration.txt` → **既存のAppLifetimeScopeに該当部分だけ取り込む**（.csにリネームして重複定義を作らない）

## 現在の仮設定

`SoundSettings.VolumeScale=1.0f`、`ImageSettings.MaxVisibleCount=3`、`TimelineSettings.AutoPlay=false`。
これらは検証用であり、既存の実機能の仕様を増やすことを意図しない。

## エラー仕様

| 入力 | 動作 |
|---|---|
| 正常な値 | JSONの値を採用 |
| 省略された項目 | プロパティ初期化子のデフォルト値を使用 |
| `null` | `NullValueHandling.Ignore` により省略と同様にデフォルト値。ログは記録しない |
| 個別の型変換エラー | `Error`イベントで報告し、その項目はデフォルト値のまま、他は読み込み継続 |
| 未定義項目 | `MissingMemberHandling.Error`で報告し、無視 |
| JSON構文不正・ルートがオブジェクトでない・ファイル不存在 | 1回エラーログを出し、設定全体をデフォルト値へ切り替え |
| 数値範囲など業務上の制約 | Loaderは判断しない。利用側で検証する |

`JObject.Parse()`で**全体の構文を確定してから**`Populate()`するので、JSONが途中で壊れていても一部だけ反映されたオブジェクトを返しません。
`Populate()`で既存のSettingsインスタンスに正常値を適用します。異常プロパティは通常設定されず既定値を維持します。`Error`イベントが `Handled=true` を付けることで読み込みを続けます。

## 設計上の留意点

1. 既存ロギングライブラリの名称・APIが提示されていないため、ログ初期化と出力の2行は統合例の中で差し替えが必要です。**その2行を含む実機プロジェクトでのコンパイルは未検証**です。
2. ロギングライブラリを `Configure()` で初期化するのは**アプリで一度だけ構築されるルートLifetimeScope**で行い、重複初期化や終了時のFlush/Disposeに注意してください。
3. `Get; private set;` を使うため、反映は起動時だけを前提とします。`JsonProperty`によってprivate setterに値が設定されます。
4. `Error`イベントで部分回復できる範囲はNewtonsoft.Jsonのデシリアライズ単位に依存します。設定型が複雑なコレクション等になったら、そのデータ構造ごとに新しいテストケースを追加してください。
5. JSONの数値文字列（例: `"0.8"`）はNewtonsoft.Jsonによって数値に変換される場合があります。JSONの型そのものまで厳密に拒否する実装ではありません。
6. 項目の値域は利用側で検証します。Loaderに `Validate()` は実装しません。

## Unity上での確認手順

1. UnityでEditModeの `AppConfigLoaderTests` を実行。
2. JSONを変えた後にPlayし、実際の利用側へSettingsが注入されていることを確認。
3. `volumeScale`に`"invalid"`を指定し、Soundのみ既定値、Image・TimelineはJSON値になることを確認。
4. JSONの構文を壊し、全設定のデフォルト復旧と、既存ログライブラリへのエラー出力を確認。
5. 起動後にファイルを編集しても、実行中の値が変わらないことを確認。

**この環境にはUnity/.NETのC#実行環境がなく、コンパイル・Unityテストは未実施です。**
