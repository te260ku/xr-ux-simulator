using System;
using System.Collections.Generic;
using System.IO;
using NUnit.Framework;

public sealed class AppConfigLoaderTests
{
    private string _directory;
    private readonly AppConfigLoader _loader = new AppConfigLoader();
    private readonly List<string> _errors = new List<string>();

    private const string ValidJson = @"
    {
      ""sound"": { ""volumeScale"": 0.6 },
      ""image"": { ""maxVisibleCount"": 5 },
      ""timeline"": { ""autoPlay"": true }
    }";

    [SetUp]
    public void SetUp()
    {
        _errors.Clear();
        _directory = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(_directory);
    }

    [TearDown]
    public void TearDown()
    {
        if (Directory.Exists(_directory))
            Directory.Delete(_directory, true);
    }

    [Test]
    public void Load_ValidJson_UsesAllProvidedValues()
    {
        var config = Load(ValidJson);

        Assert.AreEqual(0.6f, config.Sound.VolumeScale);
        Assert.AreEqual(5, config.Image.MaxVisibleCount);
        Assert.IsTrue(config.Timeline.AutoPlay);
        Assert.IsEmpty(_errors);
    }

    [Test]
    public void Load_BadFloat_PreservesOtherSettings()
    {
        var config = Load(ValidJson.Replace("0.6", "\"invalid\""));

        Assert.AreEqual(1.0f, config.Sound.VolumeScale);
        Assert.AreEqual(5, config.Image.MaxVisibleCount);
        Assert.IsTrue(config.Timeline.AutoPlay);
        Assert.That(_errors, Has.Count.EqualTo(1));
        StringAssert.Contains("sound.volumeScale", _errors[0]);
    }

    [Test]
    public void Load_BadInt_PreservesOtherSettings()
    {
        var config = Load(ValidJson.Replace("\"maxVisibleCount\": 5", "\"maxVisibleCount\": \"bad\""));

        Assert.AreEqual(0.6f, config.Sound.VolumeScale);
        Assert.AreEqual(3, config.Image.MaxVisibleCount);
        Assert.IsTrue(config.Timeline.AutoPlay);
        Assert.That(_errors, Has.Count.EqualTo(1));
    }

    [Test]
    public void Load_MissingSection_KeepsDefaultValues()
    {
        var config = Load(@"{ ""image"": { ""maxVisibleCount"": 7 } }");

        Assert.AreEqual(1.0f, config.Sound.VolumeScale);
        Assert.AreEqual(7, config.Image.MaxVisibleCount);
        Assert.IsFalse(config.Timeline.AutoPlay);
        Assert.IsEmpty(_errors);
    }

    [Test]
    public void Load_NullValue_KeepsDefaultValues()
    {
        var config = Load(@"{ ""sound"": null, ""image"": { ""maxVisibleCount"": null }, ""timeline"": { ""autoPlay"": true } }");

        Assert.AreEqual(1.0f, config.Sound.VolumeScale);
        Assert.AreEqual(3, config.Image.MaxVisibleCount);
        Assert.IsTrue(config.Timeline.AutoPlay);
        Assert.IsEmpty(_errors); // NullValueHandling.Ignore: null behaves like omitted.
    }

    [Test]
    public void Load_InvalidNestedObject_KeepsDefaultSection()
    {
        var config = Load(ValidJson.Replace("{ \"volumeScale\": 0.6 }", "\"invalid\""));

        Assert.AreEqual(1.0f, config.Sound.VolumeScale);
        Assert.AreEqual(5, config.Image.MaxVisibleCount);
        Assert.IsTrue(config.Timeline.AutoPlay);
        Assert.IsNotEmpty(_errors);
    }

    [Test]
    public void Load_UnknownSetting_IsReportedAndOtherSettingsRemain()
    {
        var config = Load(ValidJson.Replace("\"volumeScale\": 0.6", "\"volumeScale\": 0.6, \"typo\": 4"));

        Assert.AreEqual(0.6f, config.Sound.VolumeScale);
        Assert.AreEqual(5, config.Image.MaxVisibleCount);
        Assert.IsTrue(config.Timeline.AutoPlay);
        Assert.IsNotEmpty(_errors);
    }

    [Test]
    public void Load_OutOfRangeValue_IsNotValidatedHere()
    {
        var config = Load(ValidJson.Replace("0.6", "2.0"));

        Assert.AreEqual(2.0f, config.Sound.VolumeScale);
        Assert.IsEmpty(_errors);
    }

    [Test]
    public void Load_InvalidJson_UsesAllDefaults()
    {
        var config = Load("{ \"sound\": { \"volumeScale\": 0.6 }, BROKEN }");

        AssertDefaults(config);
        Assert.That(_errors, Has.Count.EqualTo(1));
    }

    [Test]
    public void Load_NonObjectRoot_UsesAllDefaults()
    {
        var config = Load("[]");

        AssertDefaults(config);
        Assert.That(_errors, Has.Count.EqualTo(1));
    }

    [Test]
    public void Load_MissingFile_UsesAllDefaults()
    {
        var path = Path.Combine(_directory, "missing.json");
        var config = _loader.LoadOrDefault(path, _errors.Add);

        AssertDefaults(config);
        Assert.That(_errors, Has.Count.EqualTo(1));
    }

    [Test]
    public void Load_RepeatedCalls_DoNotShareSettings()
    {
        var first = Load(ValidJson);
        var second = Load("{}");

        Assert.AreEqual(0.6f, first.Sound.VolumeScale);
        Assert.AreEqual(1.0f, second.Sound.VolumeScale);
    }

    private AppConfig Load(string json)
    {
        var path = Path.Combine(_directory, "appconfig.json");
        File.WriteAllText(path, json);
        return _loader.LoadOrDefault(path, _errors.Add);
    }

    private static void AssertDefaults(AppConfig config)
    {
        Assert.AreEqual(1.0f, config.Sound.VolumeScale);
        Assert.AreEqual(3, config.Image.MaxVisibleCount);
        Assert.IsFalse(config.Timeline.AutoPlay);
    }
}
