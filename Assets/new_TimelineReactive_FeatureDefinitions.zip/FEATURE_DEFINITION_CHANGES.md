# Reactive Feature Definition step

## Timeline Editor changes

- Added `TypeDefinitionFactory`.
- Moved recursive type-definition generation out of `TimelineCommandDefinitionExporter`.
- `TimelineCommandDefinitionExporter` keeps Timeline-command-specific scanning/validation only.
- `TimelineCommandDefinitionMenu` now composes `TypeDefinitionFactory` and the existing exporter.
- Timeline Runtime code is unchanged in this step.

## Reactive changes

- Added `ReactiveFeatureAttribute`.
- Added `ReactiveFeatureScanner`.
- Added `ReactiveFeatureDefinitionExporter` and definition DTOs.
- Added `Tools/Reactive/Export Feature Definitions` menu.
- Marked existing `DetectionConditionData` with `[ReactiveFeature("Detection")]`.
- Reactive Condition definitions reuse the same recursive `ParameterDefinition` tree as Timeline command arguments.
- Repository sources and `execution` are rejected for Reactive Conditions.
- Nested object types are supported recursively; circular object graphs fail during definition generation.

## Output

The Reactive exporter writes `reactive-feature-definitions.json`.
An example is included at `reactive/reactive_detection_package/Config/reactive-feature-definitions.example.json`.
