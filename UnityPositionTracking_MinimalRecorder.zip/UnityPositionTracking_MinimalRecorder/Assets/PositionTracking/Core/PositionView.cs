using UnityEngine;

namespace PositionTracking
{
    public sealed class PositionView : MonoBehaviour, IPositionView
    {
        [SerializeField] private RectTransform _displayArea;
        [SerializeField] private RectTransform _targetImage;

        private void Awake() => SetVisible(false);

        public void SetPosition(UiPosition position)
        {
            var rect = _displayArea.rect;
            _targetImage.anchoredPosition =
                new Vector2(position.X * rect.width, position.Y * rect.height);
        }

        public void SetVisible(bool visible)
        {
            if (_targetImage.gameObject.activeSelf != visible)
                _targetImage.gameObject.SetActive(visible);
        }
    }
}
