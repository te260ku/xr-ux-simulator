using System;

namespace PositionTracking
{
    public sealed class PositionPresenter
    {
        private readonly PositionTransformer _transformer;
        private readonly IPositionView _view;

        public PositionPresenter(PositionTransformer transformer, IPositionView view)
        {
            _transformer = transformer ?? throw new ArgumentNullException(nameof(transformer));
            _view = view ?? throw new ArgumentNullException(nameof(view));
        }

        public void UpdatePosition(CameraImagePosition position)
        {
            var uiPosition = _transformer.Transform(position);
            _view.SetPosition(uiPosition);
            _view.SetVisible(true);
        }

        public void Hide() => _view.SetVisible(false);
    }
}
