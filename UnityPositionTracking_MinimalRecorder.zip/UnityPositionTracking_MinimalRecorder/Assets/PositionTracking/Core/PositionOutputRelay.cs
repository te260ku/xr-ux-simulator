using System;
using UnityEngine;
using UnityEngine.Events;

namespace PositionTracking
{
    [Serializable]
    public sealed class BoundingBoxEvent : UnityEvent<float, float, float, float> { }

    // An output adapter: wire to an existing sender with a 4-float method
    // in the Inspector, or replace this registration with your own IPositionOutput.
    public sealed class PositionOutputRelay : MonoBehaviour, IPositionOutput
    {
        [SerializeField] private BoundingBoxEvent _onBoundingBox = new BoundingBoxEvent();

        public void SendBoundingBox(BoundingBox box)
        {
            if (_onBoundingBox.GetPersistentEventCount() == 0)
                throw new InvalidOperationException(
                    "PositionOutputRelay is not connected to an external sender.");
            _onBoundingBox.Invoke(box.Left, box.Top, box.Right, box.Bottom);
        }
    }
}
