namespace PositionTracking
{
    // UI-relative coordinate: center=(0,0), horizontal/vertical range [-0.5,0.5].
    public sealed class UiPosition
    {
        public float X { get; }
        public float Y { get; }

        public UiPosition(float x, float y)
        {
            X = x;
            Y = y;
        }
    }
}
