namespace PositionTracking
{
    public interface IPositionView
    {
        void SetPosition(UiPosition position);
        void SetVisible(bool visible);
    }
}
