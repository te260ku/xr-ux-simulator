namespace PositionTracking
{
    public sealed class PositionTransformer
    {
        // View handles the final Canvas/RectTransform pixel conversion.
        public UiPosition Transform(CameraImagePosition position)
        {
            return new UiPosition(position.X - 0.5f, 0.5f - position.Y);
        }
    }
}
