namespace PositionTracking
{
    public enum PositionInputMode
    {
        Detection,
        Recorded
    }
}
