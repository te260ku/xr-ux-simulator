using System;

namespace PositionTracking
{
    // Normalized image coordinates: top-left=(0,0), bottom-right=(1,1).
    public sealed class CameraImagePosition
    {
        public float X { get; }
        public float Y { get; }

        public CameraImagePosition(float x, float y)
        {
            if (float.IsNaN(x) || float.IsInfinity(x) || x < 0f || x > 1f)
                throw new ArgumentOutOfRangeException(nameof(x));
            if (float.IsNaN(y) || float.IsInfinity(y) || y < 0f || y > 1f)
                throw new ArgumentOutOfRangeException(nameof(y));
            X = x;
            Y = y;
        }
    }
}
