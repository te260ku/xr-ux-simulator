using System;

namespace PositionTracking
{
    // Keep the CS-library values unchanged (pixels OR normalized units).
    public sealed class BoundingBox
    {
        public float Left { get; }
        public float Top { get; }
        public float Right { get; }
        public float Bottom { get; }

        public BoundingBox(float left, float top, float right, float bottom)
        {
            if (!IsFinite(left) || !IsFinite(top) ||
                !IsFinite(right) || !IsFinite(bottom))
                throw new ArgumentException("Invalid bounding-box values.");
            if (right < left || bottom < top)
                throw new ArgumentException("Invalid bounding-box extents.");
            Left = left;
            Top = top;
            Right = right;
            Bottom = bottom;
        }

        public CameraImagePosition CenterNormalized(float imageWidth, float imageHeight)
        {
            if (!IsFinite(imageWidth) || !IsFinite(imageHeight) ||
                imageWidth <= 0 || imageHeight <= 0)
                throw new ArgumentOutOfRangeException(nameof(imageWidth));
            var x = (Left + Right) / (2f * imageWidth);
            var y = (Top + Bottom) / (2f * imageHeight);
            return new CameraImagePosition(x, y);
        }

        private static bool IsFinite(float value) =>
            !float.IsInfinity(value) && !float.IsNaN(value);
    }
}
