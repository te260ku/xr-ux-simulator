using System;

namespace PositionTracking
{
    public sealed class PositionCoordinator
    {
        private readonly PositionInputMode _mode;
        private readonly PositionPresenter _presenter;
        private readonly IPositionOutput _output;

        public PositionCoordinator(PositionInputMode mode,
            PositionPresenter presenter, IPositionOutput output)
        {
            _mode = mode;
            _presenter = presenter ?? throw new ArgumentNullException(nameof(presenter));
            _output = output ?? throw new ArgumentNullException(nameof(output));
        }

        // Called by the EXISTING CS-library updater in both modes.
        public void OnDetection(BoundingBox box, float imageWidth, float imageHeight)
        {
            if (box != null)
                _output.SendBoundingBox(box);
            if (_mode == PositionInputMode.Detection)
                UpdateDetectionView(box, imageWidth, imageHeight);
        }

        private void UpdateDetectionView(BoundingBox box, float imageWidth, float imageHeight)
        {
            if (box == null) _presenter.Hide();
            else _presenter.UpdatePosition(box.CenterNormalized(imageWidth, imageHeight));
        }

        // Called only by the JSON updater. No external send.
        public void OnRecordedPosition(CameraImagePosition position)
        {
            _presenter.UpdatePosition(position);
        }

        public void OnRecordedPositionLost() => _presenter.Hide();
    }
}
