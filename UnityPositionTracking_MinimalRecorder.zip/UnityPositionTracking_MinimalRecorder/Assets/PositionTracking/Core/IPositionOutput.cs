namespace PositionTracking
{
    public interface IPositionOutput
    {
        // This is always the CS-library bounding box, never recorded JSON data.
        void SendBoundingBox(BoundingBox box);
    }
}
