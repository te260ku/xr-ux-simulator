using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.Video;

namespace PositionTracking
{
    // Temporary recording tool; attach to the video RawImage.
    [RequireComponent(typeof(RawImage))]
    public sealed class VideoTraceRecorder : MonoBehaviour,
        IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        [SerializeField] private VideoPlayer _videoPlayer;
        [SerializeField] private string _savePath = "Coordinates/recorded.json";

        private PositionRecording _recording = new PositionRecording();
        private PositionStroke _stroke;
        private double _lastTime = -1;

        public void OnPointerDown(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left ||
                _stroke != null || !_videoPlayer.isPrepared) return;
            if (!TryGetPosition(eventData, out var position)) return;
            if (_videoPlayer.time < _lastTime)
            {
                Debug.LogWarning("Trace in video time order. Clear before recording again from an earlier time.");
                return;
            }
            _stroke = new PositionStroke();
            _recording.Strokes.Add(_stroke);
            AddSample(position);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (_stroke == null) return;
            if (TryGetPosition(eventData, out var position)) AddSample(position);
            else EndStroke();
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left || _stroke == null) return;
            if (TryGetPosition(eventData, out var position)) AddSample(position);
            EndStroke();
        }

        private void OnDisable() => EndStroke();

        private void AddSample(CameraImagePosition position)
        {
            var time = _videoPlayer.time;
            if (time < _lastTime)
            {
                Debug.LogWarning("Video time moved backward. Clear to record again.");
                EndStroke();
                return;
            }
            var samples = _stroke.Samples;
            var sample = new PositionSample(time, position);
            if (samples.Count > 0 && time <= samples[samples.Count - 1].Time)
                samples[samples.Count - 1] = sample;
            else
                samples.Add(sample);
            _lastTime = time;
        }

        private void EndStroke()
        {
            if (_stroke == null) return;
            if (_stroke.Samples.Count == 0) _recording.Strokes.Remove(_stroke);
            else _stroke.EndTime = Math.Max(_lastTime, _videoPlayer.time);
            _lastTime = Math.Max(_lastTime, _videoPlayer.time);
            _stroke = null;
        }

        private bool TryGetPosition(PointerEventData eventData,
            out CameraImagePosition position)
        {
            position = null;
            var area = (RectTransform)transform;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    area, eventData.position, eventData.pressEventCamera, out var local))
                return false;
            var rect = area.rect;
            if (rect.width <= 0 || rect.height <= 0 || !rect.Contains(local)) return false;
            var x = (local.x - rect.xMin) / rect.width;
            var y = (rect.yMax - local.y) / rect.height;
            position = new CameraImagePosition(x, y);
            return true;
        }

        // Connect to a Play/Pause button in the temporary recording scene.
        public void TogglePlay()
        {
            if (_videoPlayer.isPlaying) _videoPlayer.Pause();
            else _videoPlayer.Play();
        }

        public void ClearRecording()
        {
            EndStroke();
            _recording = new PositionRecording();
            _lastTime = -1;
        }

        public void SaveJson()
        {
            EndStroke();
            if (!_videoPlayer.isPrepared || _videoPlayer.length <= 0 ||
                _recording.Strokes.Count == 0)
            {
                Debug.LogWarning("Prepare the video and record at least one point before saving.");
                return;
            }
            _recording.Duration = _videoPlayer.length;
            try
            {
                var path = DataDirectory.Resolve(_savePath);
                PositionRecordingJson.Save(path, _recording);
                Debug.Log("Saved: " + path);
            }
            catch (Exception ex) { Debug.LogException(ex); }
        }
    }
}
