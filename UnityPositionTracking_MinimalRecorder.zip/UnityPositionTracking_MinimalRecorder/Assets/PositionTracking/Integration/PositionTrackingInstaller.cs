using System;
using VContainer;
using VContainer.Unity;

namespace PositionTracking
{
    // Call once from the EXISTING AppLifetimeScope.Configure().
    public static class PositionTrackingInstaller
    {
        public static void Register(IContainerBuilder builder, PositionInputMode mode,
            string recordedRelativePath, PositionView view,
            PositionPlaybackButtons playbackButtons)
        {
            if (view == null) throw new ArgumentNullException(nameof(view));
            builder.RegisterComponent(view).As<IPositionView>();
            // Register IPositionOutput separately using the application's existing sender.
            builder.Register<PositionTransformer>(Lifetime.Singleton);
            builder.Register<PositionPresenter>(Lifetime.Singleton);
            builder.Register<PositionCoordinator>(Lifetime.Singleton)
                .WithParameter("mode", mode);

            if (mode == PositionInputMode.Recorded)
                RegisterRecorded(builder, recordedRelativePath, playbackButtons);
        }

        private static void RegisterRecorded(IContainerBuilder builder,
            string relativePath, PositionPlaybackButtons buttons)
        {
            if (buttons == null) throw new ArgumentNullException(nameof(buttons));
            var path = DataDirectory.Resolve(relativePath);
            var recording = PositionRecordingJson.Load(path);
            builder.RegisterInstance(recording);
            builder.Register<RecordedPositionSource>(Lifetime.Singleton);
            builder.Register<PositionPlayback>(Lifetime.Singleton);
            builder.RegisterEntryPoint<RecordedPositionUpdater>();
            builder.RegisterComponent(buttons);
        }
    }
}
