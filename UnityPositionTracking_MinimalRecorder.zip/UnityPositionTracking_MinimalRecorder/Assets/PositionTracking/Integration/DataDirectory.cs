using System;
using System.IO;
using UnityEngine;

namespace PositionTracking
{
    public static class DataDirectory
    {
        // In Editor: sibling of Assets. In a Windows build: sibling of .exe.
        public static string Root => Path.Combine(
            Directory.GetParent(Application.dataPath).FullName, "Data");

        public static string Resolve(string relativePath)
        {
            if (string.IsNullOrWhiteSpace(relativePath))
                throw new ArgumentException("Missing Data-relative path.");
            if (Path.IsPathRooted(relativePath))
                throw new ArgumentException("Path must be relative to Data.");
            var root = Path.GetFullPath(Root);
            var full = Path.GetFullPath(Path.Combine(root, relativePath));
            var prefix = root.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            if (!full.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Path must remain inside Data.");
            return full;
        }
    }
}
