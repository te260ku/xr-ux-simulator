using VContainer.Unity;

namespace PositionTracking
{
    public sealed class RecordedPositionUpdater : ITickable
    {
        private readonly RecordedPositionSource _source;
        private readonly PositionPlayback _playback;
        private readonly PositionCoordinator _coordinator;

        public RecordedPositionUpdater(RecordedPositionSource source,
            PositionPlayback playback, PositionCoordinator coordinator)
        {
            _source = source;
            _playback = playback;
            _coordinator = coordinator;
        }

        public void Tick()
        {
            if (!_playback.IsPlaying) return;
            var time = _playback.ElapsedSeconds;
            if (time > _source.Duration)
            {
                _playback.Stop();
                _coordinator.OnRecordedPositionLost();
                return;
            }
            if (_source.TryGet(time, out var position))
                _coordinator.OnRecordedPosition(position);
            else
                _coordinator.OnRecordedPositionLost();
        }
    }
}
