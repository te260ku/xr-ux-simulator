using System;
using Newtonsoft.Json;
using System.IO;

namespace PositionTracking
{
    public sealed class PositionSample
    {
        [JsonProperty("time")] public double Time { get; set; }
        [JsonProperty("x")] public float X { get; set; }
        [JsonProperty("y")] public float Y { get; set; }

        public PositionSample() { }

        public PositionSample(double time, CameraImagePosition position)
        {
            Time = time;
            X = position.X;
            Y = position.Y;
        }

        public CameraImagePosition Position => new CameraImagePosition(X, Y);

        public void Validate()
        {
            if (double.IsNaN(Time) || double.IsInfinity(Time) || Time < 0)
                throw new InvalidDataException("Invalid sample time: " + Time);
            _ = Position;
        }
    }
}
