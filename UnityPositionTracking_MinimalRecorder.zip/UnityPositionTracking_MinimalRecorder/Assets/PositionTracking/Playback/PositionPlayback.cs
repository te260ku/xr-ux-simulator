using System.Diagnostics;

namespace PositionTracking
{
    // Stopwatch is monotonic; starts only when the operator presses Play.
    public sealed class PositionPlayback
    {
        private readonly Stopwatch _watch = new Stopwatch();
        public bool IsPlaying => _watch.IsRunning;
        public double ElapsedSeconds => _watch.Elapsed.TotalSeconds;

        public void Start() => _watch.Restart();
        public void Pause() => _watch.Stop();
        public void Resume() => _watch.Start();
        public void Stop() => _watch.Reset();
    }
}
