using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace PositionTracking
{
    public sealed class PositionStroke
    {
        [JsonProperty("endTime")]
        public double EndTime { get; set; }

        [JsonProperty("samples")]
        public List<PositionSample> Samples { get; set; } = new List<PositionSample>();

        public void Validate()
        {
            if (Samples == null || Samples.Count == 0)
                throw new InvalidDataException("A stroke needs at least one sample.");
            var previous = -1.0;
            foreach (var sample in Samples)
            {
                if (sample == null) throw new InvalidDataException("Null sample.");
                sample.Validate();
                if (sample.Time <= previous)
                    throw new InvalidDataException("Sample times must increase.");
                previous = sample.Time;
            }
            if (double.IsNaN(EndTime) || double.IsInfinity(EndTime) || EndTime < previous)
                throw new InvalidDataException("Invalid stroke end time.");
        }
    }
}
