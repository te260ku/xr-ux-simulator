using System;
using System.IO;
using Newtonsoft.Json;

namespace PositionTracking
{
    public static class PositionRecordingJson
    {
        public static PositionRecording Load(string path)
        {
            var json = File.ReadAllText(path);
            var recording = JsonConvert.DeserializeObject<PositionRecording>(json);
            if (recording == null)
                throw new InvalidDataException("Empty JSON recording: " + path);
            recording.Validate();
            return recording;
        }

        public static void Save(string path, PositionRecording recording)
        {
            if (recording == null) throw new ArgumentNullException(nameof(recording));
            recording.Validate();
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));
            File.WriteAllText(path, JsonConvert.SerializeObject(recording, Formatting.Indented));
        }
    }
}
