using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace PositionTracking
{
    public sealed class PositionRecording
    {
        [JsonProperty("duration")]
        public double Duration { get; set; }

        [JsonProperty("strokes")]
        public List<PositionStroke> Strokes { get; set; } = new List<PositionStroke>();

        public void Validate()
        {
            if (double.IsNaN(Duration) || double.IsInfinity(Duration) || Duration <= 0)
                throw new InvalidDataException("Video duration must be positive.");
            if (Strokes == null) throw new InvalidDataException("Strokes are null.");
            var previousEnd = -1.0;
            foreach (var stroke in Strokes)
            {
                if (stroke == null) throw new InvalidDataException("Null stroke.");
                stroke.Validate();
                if (stroke.Samples[0].Time < previousEnd)
                    throw new InvalidDataException("Strokes must not overlap.");
                if (stroke.EndTime > Duration + 0.001)
                    throw new InvalidDataException("Stroke exceeds video duration.");
                previousEnd = stroke.EndTime;
            }
        }
    }
}
