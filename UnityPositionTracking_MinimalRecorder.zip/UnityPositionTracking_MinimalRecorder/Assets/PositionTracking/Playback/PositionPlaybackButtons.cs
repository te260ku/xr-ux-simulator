using UnityEngine;
using VContainer;

namespace PositionTracking
{
    // Wire the public methods to Unity UI Buttons (Recorded mode only).
    public sealed class PositionPlaybackButtons : MonoBehaviour
    {
        private PositionPlayback _playback;
        private PositionCoordinator _coordinator;

        [Inject]
        public void Construct(PositionPlayback playback, PositionCoordinator coordinator)
        {
            _playback = playback;
            _coordinator = coordinator;
        }

        public void PlayFromStart() => _playback.Start();
        public void Pause() => _playback.Pause();
        public void Resume() => _playback.Resume();

        public void Stop()
        {
            _playback.Stop();
            _coordinator.OnRecordedPositionLost();
        }
    }
}
