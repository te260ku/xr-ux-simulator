using System;
using System.Collections.Generic;

namespace PositionTracking
{
    // Selects the last recorded point of the active stroke; never bridges gaps.
    public sealed class RecordedPositionSource
    {
        private readonly PositionRecording _recording;

        public double Duration => _recording.Duration;

        public RecordedPositionSource(PositionRecording recording)
        {
            _recording = recording ?? throw new ArgumentNullException(nameof(recording));
            _recording.Validate();
        }

        public bool TryGet(double time, out CameraImagePosition position)
        {
            position = null;
            if (double.IsNaN(time) || time < 0 || time > Duration)
                return false;
            foreach (var stroke in _recording.Strokes)
            {
                if (time < stroke.Samples[0].Time) return false;
                if (time > stroke.EndTime) continue;
                position = FindLatest(stroke.Samples, time).Position;
                return true;
            }
            return false;
        }

        private static PositionSample FindLatest(List<PositionSample> samples, double time)
        {
            var lo = 0;
            var hi = samples.Count - 1;
            while (lo < hi)
            {
                var mid = lo + (hi - lo + 1) / 2;
                if (samples[mid].Time <= time) lo = mid;
                else hi = mid - 1;
            }
            return samples[lo];
        }
    }
}
