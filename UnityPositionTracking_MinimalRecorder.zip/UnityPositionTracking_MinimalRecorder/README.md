# Unity 検知物体位置の記録・再生（C# 9 / Unity 6 / VContainer）

このパッケージは **実行側のMVP＋Coordinator** と、JSON作成用の**最小限の一時的な記録ツール**を含みます。R3は使いません。

## 実装した仕様

- UnityのVideoPlayerで動画を表示し、RawImage上で左クリック／ドラッグした中心座標を時系列JSONに保存する
- 記録時刻には **動画の `VideoPlayer.time`** を使う。座標はカメラ画像の左上 (0,0)、右下 (1,1) とする
- マウスボタンを離した区間は、検知物体が「位置なし」の区間になる。JSONは `strokes` 配列で区切る
- Unity実行時にはPlayボタンを押した時点を0秒とし、JSON位置を `Stopwatch` の経過時刻で引き出す
- 別PCの動画は**ユーザーが手動で同時に開始**する。PC間通信・時刻同期は行わない
- **CSライブラリは両モードで引き続き取得**し、CS由来のBBox座標を外部送信する
- CSライブラリモードだけ、CSのBBox中心でUI画像を移動する
- JSONモードだけ、記録した中心座標でUI画像を移動する。JSON由来の座標は外部送信しない
- `PositionCoordinator` が入力モードを保持し、`PositionPresenter` がUI座標へ変換し、`PositionView` がRectTransformを変更する

## 依存パッケージ

- Unity 6系（URPでも利用可）
- VContainer（既存プロジェクトのもの）
- Newtonsoft.Json（`com.unity.nuget.newtonsoft-json`）
- Unity UI (`UnityEngine.UI`)、Unity Video (`UnityEngine.Video`)、EventSystem

`Assets/PositionTracking` 以下を Unity の `Assets` にコピーします。

## 1. 一時的な記録ツール（最小構成）

記録専用のシーンを1つ用意してください。**本番ビルドにはそのシーンを含める必要はありません。**

1. `Canvas`、`EventSystem`、`RawImage`、`VideoPlayer` を配置します。
2. `VideoPlayer` の `Play On Awake=false`、`Is Looping=false`、`Render Mode=Render Texture` を設定し、`RawImage.texture`と同じRenderTextureを割り当てます。
3. `RawImage` に `VideoTraceRecorder` を追加し、`VideoPlayer` だけInspectorで指定します。`RawImage` の `Raycast Target=true` を確認してください。
4. `RawImage` のサイズを**実際の動画表示範囲**と一致させます。動画内に黒帯・余白があると座標がずれます。
5. ボタンを2つ作成し、`TogglePlay`（再生・一時停止）、`SaveJson`（保存）に接続します。録り直しを頻繁に行う場合のみ3つ目の `ClearRecording` ボタンを追加します。
6. 動画再生中に対象物体の中心を左クリックし、押したままドラッグしてなぞります。ボタンを離すとその追跡区間が終了します。再度なぞると別の区間が追加されます。
7. 保存すると`Data/Coordinates/recorded.json`が作成／上書きされます。保存先は`VideoTraceRecorder`の`Save Path`から変更できます。

**実装しないもの：**軌跡表示、記録点の編集、コマ送り、再生速度変更、自動追跡、独自UI、R3、専用DI登録。記録ツールは単一の`VideoTraceRecorder.cs`で完結し、既存の時系列JSONデータ型と保存処理だけを再利用します。

**制約：**座標は動画左上原点の0～1正規化値、記録時刻は`VideoPlayer.time`です。記録順は動画時刻に対して昇順のみです。巻き戻して修正する場合は`ClearRecording`して録り直します。マウスを離した区間は、実行時にUI画像を非表示にする区間になります。マウスイベントの位置変化時にサンプルを追加し、同一動画時刻のサンプルは最後の値で置き換えます。

## 2. JSONフォーマット

`Examples/recorded.json` を参照してください。

```json
{
  "duration": 5.0,
  "strokes": [
    {
      "endTime": 1.25,
      "samples": [
        { "time": 0.25, "x": 0.35, "y": 0.55 },
        { "time": 0.50, "x": 0.40, "y": 0.57 }
      ]
    }
  ]
}
```

- `duration`: 動画長さ（秒）。
- `time`: 動画の再生時刻（秒）。
- `x,y`: 動画の中心座標、左上原点、0～1。
- `endTime`: マウスを離した時刻。ストローク間の空白ではUI画像を非表示にします。

**JSONにBBoxや検知種別は追加しません。** 複数物体を同時に記録する形式ではありません（現実装はUI表示対象１つ）。

## 3. 実行側Unityシーンの設定

1. UI画像（移動対象）を配置し、親に表示領域となる `RectTransform` を用意します。
2. UI画像のanchorMin/anchorMaxを**両方(0.5,0.5)**、位置基準となるアンカーを中央にして、対象画像のRectTransformを直接この表示領域の子にします。`PositionView` の `Display Area`, `Target Image` を割り当てます。
3. JSON再生用に `PositionPlaybackButtons` を持つGameObjectと、PlayFromStart / Pause / Resume / Stopを呼ぶUnity UI Buttonsを作ります。
4. `PositionTrackingInstaller.Register` を**既存**`AppLifetimeScope.Configure()`内で一度だけ呼びます。以下のDIコード例を参照してください。
5. 既存`DetectionUpdater`に、CSライブラリからBBoxを読み取った直後、Coordinatorに渡す1行を追加します。既存の外部データ取得や座標以外の処理は維持します。
6. CSライブラリから外部送信する既存のアダプターを`IPositionOutput`として登録します。利用できる既存のMonoBehaviour送信コンポーネントがある場合は、付属の `PositionOutputRelay` の4 float UnityEventに接続しても構いません。

### 既存LifetimeScope.Configure()への追加例

```csharp
[SerializeField] private PositionView _positionView;
[SerializeField] private PositionPlaybackButtons _playbackButtons;
[SerializeField] private PositionOutputRelay _outputRelay;

protected override void Configure(IContainerBuilder builder)
{
    var config = AppConfigLoader.LoadOrDefault();  // プロジェクトに既存のもの
    var mode = config.Coordinate.Source switch
    {
        "csLibrary" => PositionInputMode.Detection,
        "recorded"  => PositionInputMode.Recorded,
        _ => throw new ArgumentException("Unknown position input mode.")
    };

    // 既存の送信処理がIPositionOutputを実装していれば、そちらを登録する。
    // これは付属RelayをInspectorから使う場合の例。
    builder.RegisterComponent(_outputRelay).As<IPositionOutput>();

    PositionTrackingInstaller.Register(
        builder, mode, config.Coordinate.FilePath,
        _positionView, _playbackButtons);

    // CSライブラリの既存登録と既存DetectionUpdaterのエントリポイント登録はそのまま。
    // 例: builder.RegisterEntryPoint<DetectionUpdater>();
}
```

上記は**既存コードへ組み込むための例**であり、こちらのパッケージには実プロジェクトの `AppConfig` / `AppConfigLoader` / 変更不可CS SDK の実装は含みません。`_outputRelay`を使わない場合は、既存の外部出力アダプターを`IPositionOutput`として登録してください。

VContainerは`RegisterComponent`でInspector指定済みMonoBehaviourを登録でき、登録対象に`[Inject]`メソッドがあれば注入します。`RegisterEntryPoint`は`ITickable`をUnity Updateで呼び出します。

### 既存DetectionUpdaterで行う最小変更

```csharp
// 既存DetectionUpdaterのコンストラクタ注入に追加
private readonly PositionCoordinator _positionCoordinator;

// CSライブラリから取得した後、既存データ処理を維持したまま追加する
// bbox.Left/Top/Right/Bottom は「元のCS座標値」を渡す（ここでは正規化しない）
var box = new BoundingBox(bbox.Left, bbox.Top, bbox.Right, bbox.Bottom);
_positionCoordinator.OnDetection(box, cameraImageWidth, cameraImageHeight);
```

- CSライブラリが**ピクセルBBox**を返すなら`cameraImageWidth/Height`には動画・カメラ画像の実サイズ（例:1920、1080）を渡します。
- CSライブラリが**0～1正規化BBox**を返すなら両方`1f`を渡します。
- 外部へ送られる`BoundingBox`は元の値を保持します。
- 対象物体を検知できなかったときは `_positionCoordinator.OnDetection(null, 1f, 1f)` を呼びます。この場合、外部BBox送信はスキップし、DetectionモードではUI画像を非表示にします。**CSライブラリの他情報や未検知イベント送信は既存処理で維持**してください。
- CSデータの取得・外部送信が100Hz固定なら、既存の周期制御を維持してください。本実装のJSONのUpdaterだけVContainer `ITickable`でUnity Updateごとに動きます。

## 4. 実行操作

1. `Data/Coordinates/recorded.json` を配置し、既存の `appconfig.json` の入力ソースを `recorded` にします。
2. Unityを起動し、別PCで同じ動画を表示・再生待機にします。
3. 動画再生PCとUnityの `PlayFromStart` ボタンを**手動でなるべく同時**に押します。
4. Unity側は押された時点から0秒の時刻を進めて対応座標を選択します。中断区間や動画終端後はUI画像を非表示にします。
5. `Stop`は時刻をリセットします。`Pause` / `Resume` はUnity側だけの操作であり、別PCの動画は連動しません。

## 5. 注意点・残る実プロジェクトとの結合部分

- SDK側の**実際の型名・フィールド・フレームサイズ・取得API**、および外部送信プロトコルは未提供のため推測して実装していません。上記の2箇所を既存プロジェクトに合わせて接続する必要があります。
- CSライブラリに複数物体がいる場合は、既存の「表示対象物体の選択」ロジックで選定してから上記を呼ぶか、データ構造・Viewを複数物体対応に拡張します。
- 付属 `PositionOutputRelay` は送信先がInspectorに1件も指定されていない場合に例外を出し、外部送信の欠落を隠しません。
- JSONをマウスで記録して保存する際、`VideoPlayer.length`と`VideoPlayer.time`が利用可能な動画ファイルである必要があります。
- 2台のPC間に自動同期はありません。手動開始誤差や長時間の再生ドリフトは補正しません。
- `PositionView`は単純なCanvas向けです。黒セラ曲面への投影など独自の変換が必要な場合は、`PositionTransformer`を差し替えます。
- EditModeテスト例は `Tests~` にあります。Unity Test FrameworkのEditMode用テストアセンブリへ移して利用できます。

## Unity/VContainer公式資料

- VContainer: https://vcontainer.hadashikick.jp/integrations/entrypoint
- VContainer Component registration: https://vcontainer.hadashikick.jp/registering/register-monobehaviour
- Unity VideoPlayer: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/video/videoplayer
- Unity RectTransformUtility: https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/recttransformutility/screenpointtolocalpointinrectangle
