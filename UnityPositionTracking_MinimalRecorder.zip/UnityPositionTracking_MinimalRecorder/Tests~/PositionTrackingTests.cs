// Move this file into an EditMode test assembly using NUnit / Unity Test Framework.
using System;
using NUnit.Framework;
using PositionTracking;

public sealed class PositionTrackingTests
{
    private sealed class FakeView : IPositionView
    {
        public UiPosition Last;
        public bool Visible;
        public void SetPosition(UiPosition position) => Last = position;
        public void SetVisible(bool visible) => Visible = visible;
    }

    private sealed class FakeOutput : IPositionOutput
    {
        public int Calls;
        public BoundingBox Last;
        public void SendBoundingBox(BoundingBox box) { Calls++; Last = box; }
    }

    [Test]
    public void DetectionMode_UpdatesViewAndSendsOriginalBox()
    {
        var view = new FakeView();
        var output = new FakeOutput();
        var coordinator = Create(PositionInputMode.Detection, view, output);
        var box = new BoundingBox(100, 50, 300, 150);
        coordinator.OnDetection(box, 400, 200);
        Assert.That(output.Last, Is.SameAs(box));
        Assert.That(output.Calls, Is.EqualTo(1));
        Assert.That(view.Visible, Is.True);
        Assert.That(view.Last.X, Is.EqualTo(0).Within(0.0001));
        Assert.That(view.Last.Y, Is.EqualTo(0).Within(0.0001));
    }

    [Test]
    public void RecordedMode_AlwaysSendsDetectionButUsesOnlyRecordedForUi()
    {
        var view = new FakeView();
        var output = new FakeOutput();
        var coordinator = Create(PositionInputMode.Recorded, view, output);
        coordinator.OnDetection(new BoundingBox(0, 0, 50, 50), 100, 100);
        Assert.That(output.Calls, Is.EqualTo(1));
        Assert.That(view.Visible, Is.False);
        coordinator.OnRecordedPosition(new CameraImagePosition(0.2f, 0.7f));
        Assert.That(output.Calls, Is.EqualTo(1));
        Assert.That(view.Visible, Is.True);
        Assert.That(view.Last.X, Is.EqualTo(-0.3f).Within(0.0001));
        Assert.That(view.Last.Y, Is.EqualTo(-0.2f).Within(0.0001));
    }

    [Test]
    public void RecordedSource_DoesNotBridgeMouseUpGaps()
    {
        var recording = new PositionRecording { Duration = 6 };
        recording.Strokes.Add(new PositionStroke
        {
            EndTime = 2.5,
            Samples = new System.Collections.Generic.List<PositionSample>
            {
                new PositionSample(1, new CameraImagePosition(0.2f, 0.4f)),
                new PositionSample(2, new CameraImagePosition(0.3f, 0.5f))
            }
        });
        recording.Strokes.Add(new PositionStroke
        {
            EndTime = 5,
            Samples = new System.Collections.Generic.List<PositionSample>
            {
                new PositionSample(4, new CameraImagePosition(0.8f, 0.6f))
            }
        });
        var source = new RecordedPositionSource(recording);
        Assert.That(source.TryGet(1.5, out var first), Is.True);
        Assert.That(first.X, Is.EqualTo(0.2f));
        Assert.That(source.TryGet(3.0, out _), Is.False);
        Assert.That(source.TryGet(4.5, out var second), Is.True);
        Assert.That(second.X, Is.EqualTo(0.8f));
        Assert.That(source.TryGet(5.5, out _), Is.False);
    }

    private static PositionCoordinator Create(PositionInputMode mode, FakeView view,
        FakeOutput output)
    {
        var presenter = new PositionPresenter(new PositionTransformer(), view);
        return new PositionCoordinator(mode, presenter, output);
    }
}
