using System;
using System.Collections.Generic;
using UnityEngine;
using VContainer.Unity;

public sealed class KeyboardCommandUpdater : IStartable, ITickable
{
    private readonly KeyboardCommandConfig _config;
    private readonly TimelineCommandExecutionFactory _factory;
    private readonly Dictionary<KeyCode, TimelineCommandExecution> _commands = new();
    private bool _active;

    public KeyboardCommandUpdater(
        KeyboardCommandConfig config,
        TimelineCommandExecutionFactory factory)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _factory = factory ?? throw new ArgumentNullException(nameof(factory));
    }

    public void Start()
    {
        _active = Application.isEditor || _config.EnabledInBuild;
        if (!_active) return;

        foreach (var binding in _config.Bindings)
            Register(binding);
    }

    public void Tick()
    {
        if (!_active) return;
        foreach (var pair in _commands)
        {
            if (Input.GetKeyDown(pair.Key))
                pair.Value.Execute();
        }
    }

    private void Register(KeyboardCommandBinding binding)
    {
        if (binding == null || binding.Key == KeyCode.None)
            throw new InvalidOperationException("Keyboard binding must specify a key.");
        if (_commands.ContainsKey(binding.Key))
            throw new InvalidOperationException($"Duplicate keyboard binding: {binding.Key}");

        var execution = _factory.Create(binding.CommandId, binding.ArgumentsJson);
        _commands.Add(binding.Key, execution);
    }
}
