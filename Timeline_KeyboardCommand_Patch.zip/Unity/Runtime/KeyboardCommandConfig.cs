using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "KeyboardCommands", menuName = "Debug/Keyboard Commands")]
public sealed class KeyboardCommandConfig : ScriptableObject
{
    [SerializeField] private bool _enabledInBuild;
    [SerializeField] private List<KeyboardCommandBinding> _bindings = new();

    public bool EnabledInBuild => _enabledInBuild;
    public IReadOnlyList<KeyboardCommandBinding> Bindings => _bindings;
}

[Serializable]
public sealed class KeyboardCommandBinding
{
    [SerializeField] private KeyCode _key = KeyCode.None;
    [SerializeField] private string _commandId = "";
    [SerializeField, HideInInspector] private string _argumentsJson = "{}";

    public KeyCode Key => _key;
    public string CommandId => _commandId;
    public string ArgumentsJson => _argumentsJson;
}
