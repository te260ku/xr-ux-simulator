using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Serialization;

internal sealed class KeyboardCommandDefinitionCatalog
{
    private readonly Dictionary<string, CommandDefinition> _byId;
    public string[] Names { get; }
    public string[] Options { get; }

    public KeyboardCommandDefinitionCatalog()
    {
        var exporter = new TimelineCommandDefinitionExporter(
            new TimelineCommandScanner(),
            new CamelCasePropertyNamesContractResolver());
        var definitions = exporter.CreateDefinitions().Commands;
        _byId = definitions.ToDictionary(x => x.Id, StringComparer.Ordinal);
        Names = definitions.Select(x => x.Id).ToArray();
        Options = new[] { "-- Select command --" }.Concat(Names).ToArray();
    }

    public CommandDefinition Find(string id)
    {
        return _byId.TryGetValue(id ?? "", out var definition) ? definition : null;
    }
}
