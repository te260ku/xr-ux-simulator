using Newtonsoft.Json.Linq;

internal static class KeyboardCommandArgumentDefaults
{
    public static JObject CreateArguments(CommandDefinition command)
    {
        var result = new JObject();
        foreach (var parameter in command.Parameters)
            result[parameter.Name] = CreateValue(parameter);
        return result;
    }

    public static JToken CreateValue(ParameterDefinition definition)
    {
        if (definition.Type == "execution")
            return new JObject { ["command"] = "", ["arguments"] = new JObject() };

        if (definition.Type == "object")
            return CreateObject(definition);

        if (definition.DefaultValue != null)
            return JToken.FromObject(definition.DefaultValue);

        switch (definition.Type)
        {
            case "int": return new JValue(0);
            case "float": return new JValue(0f);
            case "bool": return new JValue(false);
            case "enum": return new JValue(definition.Options.Length == 0 ? "" : definition.Options[0]);
            default: return new JValue("");
        }
    }

    private static JObject CreateObject(ParameterDefinition definition)
    {
        var obj = new JObject();
        foreach (var property in definition.Properties)
            obj[property.Name] = CreateValue(property);

        if (definition.Source != null && definition.DefaultValue != null)
            obj[definition.Properties[0].Name] = JToken.FromObject(definition.DefaultValue);
        return obj;
    }
}
