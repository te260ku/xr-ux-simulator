using System;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEngine;

internal sealed class KeyboardCommandArgumentsDrawer
{
    private const int MaxExecutionDepth = 6;
    private readonly KeyboardCommandDefinitionCatalog _catalog;

    public KeyboardCommandArgumentsDrawer(KeyboardCommandDefinitionCatalog catalog)
    {
        _catalog = catalog;
    }

    public void DrawArguments(CommandDefinition command, JObject arguments, int depth = 0)
    {
        foreach (var parameter in command.Parameters)
            DrawField(parameter, arguments, depth);
    }

    private void DrawField(ParameterDefinition field, JObject parent, int depth)
    {
        if (parent[field.Name] == null)
            parent[field.Name] = KeyboardCommandArgumentDefaults.CreateValue(field);
        var token = parent[field.Name];

        if (field.Type == "object")
            DrawObject(field, parent, depth);
        else if (field.Type == "execution")
            DrawExecution(field, parent, depth);
        else
            parent[field.Name] = KeyboardCommandArgumentFields.Draw(field, token);
    }

    private void DrawObject(ParameterDefinition field, JObject parent, int depth)
    {
        var obj = parent[field.Name] as JObject;
        if (obj == null) { obj = new JObject(); parent[field.Name] = obj; }

        EditorGUILayout.LabelField(ObjectNames.NicifyVariableName(field.Name), EditorStyles.boldLabel);
        EditorGUI.indentLevel++;
        foreach (var property in field.Properties)
            DrawField(property, obj, depth);
        EditorGUI.indentLevel--;
    }

    private void DrawExecution(ParameterDefinition field, JObject parent, int depth)
    {
        if (depth >= MaxExecutionDepth)
        {
            EditorGUILayout.HelpBox("Maximum nested Execution editor depth reached.", MessageType.Warning);
            return;
        }

        EditorGUILayout.LabelField(ObjectNames.NicifyVariableName(field.Name), EditorStyles.boldLabel);
        var execution = parent[field.Name] as JObject ?? new JObject();
        parent[field.Name] = execution;
        DrawNestedCommand(execution, depth + 1);
    }

    private void DrawNestedCommand(JObject execution, int depth)
    {
        var current = (string)execution["command"] ?? "";
        var index = Array.IndexOf(_catalog.Names, current) + 1;
        var next = EditorGUILayout.Popup("Command", index, _catalog.Options);
        if (next != index)
        {
            var newId = next == 0 ? "" : _catalog.Names[next - 1];
            execution["command"] = newId;
            execution["arguments"] = newId.Length == 0
                ? new JObject() : KeyboardCommandArgumentDefaults.CreateArguments(_catalog.Find(newId));
        }
        var command = _catalog.Find((string)execution["command"]);
        if (command == null)
        {
            EditorGUILayout.HelpBox("Select a valid nested command.", MessageType.Warning);
            return;
        }
        var arguments = execution["arguments"] as JObject ?? new JObject();
        execution["arguments"] = arguments;
        EditorGUI.indentLevel++;
        DrawArguments(command, arguments, depth);
        EditorGUI.indentLevel--;
    }
}
