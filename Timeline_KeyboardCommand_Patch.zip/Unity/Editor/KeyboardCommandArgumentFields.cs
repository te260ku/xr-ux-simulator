using System;
using System.Linq;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEngine;

internal static class KeyboardCommandArgumentFields
{
    public static JToken Draw(ParameterDefinition field, JToken token)
    {
        var label = ObjectNames.NicifyVariableName(field.Name);
        switch (field.Type)
        {
            case "string": return DrawString(field, label, token);
            case "int": return new JValue(EditorGUILayout.IntField(label, (int)token));
            case "float": return new JValue(EditorGUILayout.FloatField(label, (float)token));
            case "bool": return new JValue(EditorGUILayout.Toggle(label, (bool)token));
            case "enum": return DrawEnum(field, label, token);
            default: return token;
        }
    }

    private static JToken DrawString(ParameterDefinition field, string label, JToken token)
    {
        var current = (string)token ?? "";
        if (field.FilePath != true)
        {
            var value = EditorGUILayout.TextField(label, current);
            WarnIfRequired(field, value);
            return new JValue(value);
        }

        EditorGUILayout.BeginHorizontal();
        var value = EditorGUILayout.TextField(label, current);
        if (GUILayout.Button("Browse", GUILayout.Width(70)))
        {
            var selected = EditorUtility.OpenFilePanel(label, "", "");
            if (!string.IsNullOrEmpty(selected)) value = selected;
        }
        EditorGUILayout.EndHorizontal();
        WarnIfRequired(field, value);
        return new JValue(value);
    }

    private static JToken DrawEnum(ParameterDefinition field, string label, JToken token)
    {
        var current = (string)token ?? "";
        if (field.MultiSelect == true)
        {
            var options = field.Options.Where(x => x != "None" && x != "0").ToArray();
            if (options.Length > 30)
                return new JValue(EditorGUILayout.TextField(label + " (flags)", current));

            var values = current.Split(',').Select(x => x.Trim()).ToArray();
            var mask = 0;
            for (var i = 0; i < options.Length; i++)
                if (values.Contains(options[i])) mask |= 1 << i;
            var next = EditorGUILayout.MaskField(label, mask, options);
            var empty = field.Options.Contains("None") ? "None" : "0";
            return new JValue(MaskToString(next, options, empty));
        }

        var selected = Array.IndexOf(field.Options, current);
        selected = EditorGUILayout.Popup(label, Math.Max(0, selected), field.Options);
        return new JValue(field.Options.Length == 0 ? "" : field.Options[selected]);
    }

    private static void WarnIfRequired(ParameterDefinition field, string value)
    {
        if (field.Nullable != true && string.IsNullOrWhiteSpace(value))
            EditorGUILayout.HelpBox($"{field.Name} is required.", MessageType.Warning);
    }

    private static string MaskToString(int mask, string[] options, string empty)
    {
        if (mask == 0) return empty;
        return string.Join(", ", options.Where((_, i) => (mask & (1 << i)) != 0));
    }
}
