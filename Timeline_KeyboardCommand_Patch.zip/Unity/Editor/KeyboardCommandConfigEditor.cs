using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(KeyboardCommandConfig))]
public sealed class KeyboardCommandConfigEditor : Editor
{
    private KeyboardCommandDefinitionCatalog _catalog;
    private KeyboardCommandArgumentsDrawer _drawer;
    private string _catalogError;

    private void OnEnable()
    {
        try
        {
            _catalog = new KeyboardCommandDefinitionCatalog();
            _drawer = new KeyboardCommandArgumentsDrawer(_catalog);
        }
        catch (Exception exception)
        {
            _catalogError = exception.Message;
        }
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();
        EditorGUILayout.PropertyField(serializedObject.FindProperty("_enabledInBuild"),
            new GUIContent("Enable In Standalone Build"));
        if (_catalog == null)
        {
            EditorGUILayout.HelpBox(_catalogError, MessageType.Error);
            serializedObject.ApplyModifiedProperties();
            return;
        }

        var bindings = serializedObject.FindProperty("_bindings");
        for (var i = 0; i < bindings.arraySize; i++)
        {
            if (DrawBinding(bindings, i)) break;
        }
        if (GUILayout.Button("Add Binding"))
            AddBinding(bindings);
        serializedObject.ApplyModifiedProperties();
    }

    private bool DrawBinding(SerializedProperty bindings, int index)
    {
        var item = bindings.GetArrayElementAtIndex(index);
        EditorGUILayout.BeginVertical(EditorStyles.helpBox);
        EditorGUILayout.LabelField($"Binding {index + 1}", EditorStyles.boldLabel);
        EditorGUILayout.PropertyField(item.FindPropertyRelative("_key"), new GUIContent("Key"));
        DrawCommand(item);
        DrawArguments(item);
        var remove = GUILayout.Button("Remove Binding");
        EditorGUILayout.EndVertical();
        if (remove) bindings.DeleteArrayElementAtIndex(index);
        return remove;
    }

    private void DrawCommand(SerializedProperty item)
    {
        var commandProp = item.FindPropertyRelative("_commandId");
        var argsProp = item.FindPropertyRelative("_argumentsJson");
        var selected = Array.IndexOf(_catalog.Names, commandProp.stringValue) + 1;
        var next = EditorGUILayout.Popup("Command", selected, _catalog.Options);
        if (selected == 0 && !string.IsNullOrWhiteSpace(commandProp.stringValue))
            EditorGUILayout.HelpBox("Command ID no longer exists.", MessageType.Warning);
        if (next == selected) return;

        commandProp.stringValue = next == 0 ? "" : _catalog.Names[next - 1];
        var definition = _catalog.Find(commandProp.stringValue);
        argsProp.stringValue = definition == null ? "{}" :
            KeyboardCommandArgumentDefaults.CreateArguments(definition).ToString(Formatting.None);
    }

    private void DrawArguments(SerializedProperty item)
    {
        var command = _catalog.Find(item.FindPropertyRelative("_commandId").stringValue);
        if (command == null)
        {
            EditorGUILayout.HelpBox("Select a valid command.", MessageType.Info);
            return;
        }
        var argsProp = item.FindPropertyRelative("_argumentsJson");
        JObject arguments;
        try { arguments = JObject.Parse(argsProp.stringValue); }
        catch (JsonException)
        {
            EditorGUILayout.HelpBox("Invalid arguments JSON.", MessageType.Error);
            if (GUILayout.Button("Reset Arguments"))
                argsProp.stringValue = KeyboardCommandArgumentDefaults
                    .CreateArguments(command).ToString(Formatting.None);
            return;
        }

        var original = (JObject)arguments.DeepClone();
        EditorGUI.BeginChangeCheck();
        _drawer.DrawArguments(command, arguments);
        if (EditorGUI.EndChangeCheck() || !JToken.DeepEquals(original, arguments))
            argsProp.stringValue = arguments.ToString(Formatting.None);
    }

    private static void AddBinding(SerializedProperty bindings)
    {
        var index = bindings.arraySize++;
        var item = bindings.GetArrayElementAtIndex(index);
        item.FindPropertyRelative("_key").enumValueIndex = 0;
        item.FindPropertyRelative("_commandId").stringValue = "";
        item.FindPropertyRelative("_argumentsJson").stringValue = "{}";
    }
}
