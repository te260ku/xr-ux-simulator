# Keyboard → Timeline Command (Unity 6 / VContainer)

## What this adds

The `KeyboardCommandConfig` ScriptableObject stores `KeyCode` → `TimelineCommandId` → argument values.
The Custom Inspector discovers every `[TimelineCommand]` method via the **existing**
`TimelineCommandDefinitionExporter` (no parallel command registry).
Arguments are shown as typed controls and stored as the **same JSON argument object** used by the timeline.
Supported editor field shapes: string, int, float, bool, enum, flags enum, nested object/value object,
`TimelineCommandExecution` as a direct command argument, `[TimelineDefaultValue]`,
`[TimelineFilePath]`, and `[TimelineNullable]` (empty strings permitted).
Source-marked Repository ID values are editable as strings (not synchronized dropdowns).

## Setup

1. Copy the `Unity/Runtime` and `Unity/Editor` C# files to corresponding `Assets/...` paths.
   This ZIP includes a full snapshot of the timeline package; **merge changes instead of
   overwriting locally customized timeline files**.
2. The modified `TimelineRepository` now receives `TimelineCommandExecutionFactory`.
   Register the factory with VContainer (see `Unity/Samples/TimelineCompositionRootExample.cs`).
3. In Unity: `Assets → Create → Debug → Keyboard Commands`.
4. Click the ScriptableObject. Choose a Key and a Command, then edit its Arguments in Inspector.
5. In the VContainer `LifetimeScope` (sample: `TimelineCompositionRootExample`), drag the
   ScriptableObject into `_keyboardCommands`.
6. Enter Play mode. Press the assigned key while the Game view has keyboard focus.
7. For standalone Windows builds, **Enable In Standalone Build** must be checked on the asset.
   Default is false to prevent accidental execution in production builds.

## Input System note

This implementation uses `UnityEngine.KeyCode` and `UnityEngine.Input.GetKeyDown`.
In `Project Settings → Player → Active Input Handling`, choose **Input Manager (Old)**
or **Both**. It does not currently implement New Input System-only input polling.
Keyboard shortcuts may be intercepted by the Editor while Game view lacks focus.

## Execution rules

- Exactly one command per KeyCode; duplicate keys are rejected during startup.
- `KeyCode.None` is rejected.
- Commands are resolved and argument JSON is deserialized/validated during `IStartable.Start()`.
- Each `Input.GetKeyDown` triggers the matching existing `TimelineCommandExecution.Execute()`.
- Commands execute regardless of whether `TimelinePlayer` is playing.
- The updater implements `ITickable` and is registered through `builder.RegisterEntryPoint<KeyboardCommandUpdater>()`.
- The input implementation is intentionally **not enabled in standalone builds by default**.
- Runtime parse/execution errors use the normal Unity exception/debug pipeline.
- Nested executions are editable to six levels; deeper nesting is not rewritten by the editor UI.

## Regression checklist (Unity Editor)

1. Create config asset. Add F1 → PlaySound, SoundId = Warning01, volume = 0.8.
   Enter Play mode and press F1; verify sound/log output.
2. Add F2 → SetUiState; change target.value and enum; confirm the selected state is received.
3. Add a command accepting a direct nested TimelineCommandExecution. Set the nested
   command and arguments. Press the key; confirm the nested execution object is supplied.
4. Press each key while TimelinePlayer is stopped. Confirm commands still execute.
5. Select the same key in two bindings. On startup, verify a clear duplicate-key error.
6. Select a command that no longer exists. Verify the Inspector warning and the startup error.
7. Set a required string to empty. Confirm the Inspector warning; no silent substitution occurs.
8. Check **Enable In Standalone Build** and test keyboard input in a Windows build.
   Uncheck it and confirm no keyboard-command execution in the same build configuration.
9. Confirm ordinary timeline JSON still loads and runs (TimelineRepository now uses Factory).

## Notes / limits

- Actual C# compilation and Unity Play Mode tests **must be run in the Unity project**.
  They cannot be executed in this environment.
- The command-definition metadata is computed from current C# at Inspector initialization,
  rather than loading a potentially stale exported `command-definitions.json` file.
- Repository IDs are currently manual text fields. The external CSV/JSON repository sources are
  not directly accessible to this Inspector without a project-specific file-loading contract.
- File Browse returns an OS path. For portable external assets, input an appropriate relative path manually.
- This implementation does not provide a runtime key-binding overlay; a small overlay can be added separately.
- The existing timeline `TimelineCommandExecution` retains its original non-null argument rule.
  `[TimelineNullable]` permits empty *editor values*, not JSON null.
