using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

public sealed class BuildDataFolderCopier : IPreprocessBuildWithReport, IPostprocessBuildWithReport
{
    public int callbackOrder => 0;

    public void OnPreprocessBuild(BuildReport report)
    {
        if (report.summary.platform != BuildTarget.StandaloneWindows64)
            return;

        var source = GetSourceDirectory();
        var destination = GetDestinationDirectory(report);
        ValidatePaths(source, destination);

        if (!Directory.Exists(destination))
            return;

        if (Application.isBatchMode)
            throw new BuildFailedException("Data folder already exists. Interactive confirmation is required.");

        var confirmed = EditorUtility.DisplayDialog(
            "Dataフォルダの上書き確認",
            $"コピー先にDataフォルダが存在します。\n\n{destination}\n\n" +
            "同名ファイルは上書きされます。\n" +
            "コピー先にのみ存在するファイルは削除されません。\n\n" +
            "上書きコピーしてビルドを続行しますか？",
            "上書きしてビルド",
            "キャンセル");

        if (!confirmed)
            throw new BuildFailedException("Data folder copy was not approved. Build cancelled.");
    }

    public void OnPostprocessBuild(BuildReport report)
    {
        if (report.summary.platform != BuildTarget.StandaloneWindows64)
            return;

        var source = GetSourceDirectory();
        var destination = GetDestinationDirectory(report);
        ValidatePaths(source, destination);
        CopyDirectory(source, destination);

        Debug.Log($"Data folder copied: {source} -> {destination}");
    }

    private static string GetSourceDirectory()
    {
        return Path.GetFullPath(Path.Combine(Application.dataPath, "..", "Data"));
    }

    private static string GetDestinationDirectory(BuildReport report)
    {
        var buildDirectory = Path.GetDirectoryName(report.summary.outputPath);
        return Path.GetFullPath(Path.Combine(buildDirectory, "Data"));
    }

    private static void ValidatePaths(string source, string destination)
    {
        if (!Directory.Exists(source))
            throw new BuildFailedException($"Source Data folder not found: {source}");

        if (IsSameOrChild(source, destination) || IsSameOrChild(destination, source))
            throw new BuildFailedException("Source and destination Data folders must not overlap.");
    }

    private static bool IsSameOrChild(string path, string parent)
    {
        return path.Equals(parent, StringComparison.OrdinalIgnoreCase) ||
               path.StartsWith(parent + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
    }

    private static void CopyDirectory(string source, string destination)
    {
        Directory.CreateDirectory(destination);

        foreach (var file in Directory.GetFiles(source))
            File.Copy(file, Path.Combine(destination, Path.GetFileName(file)), true);

        foreach (var directory in Directory.GetDirectories(source))
            CopyDirectory(directory, Path.Combine(destination, Path.GetFileName(directory)));
    }
}
