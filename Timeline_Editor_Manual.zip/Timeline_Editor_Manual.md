# Timeline Editor 簡易マニュアル

## 1. 起動

`Timeline Editor` のHTMLファイルを **Chrome または Edge** で `file:///` から開きます。

Root Directoryを使用する際は、ブラウザからフォルダ読み取りの許可を求められます。対象となるデータフォルダのみを選択してください。

---

## 2. 基本的な使用順序

1. **Command Definitions** を読み込む
2. 必要な **Repository CSV** を読み込む
3. **Root Directory** を選択する
4. **Timeline** を新規作成、またはJSONを読み込む
5. Timelineを編集する
6. **検証**
7. **保存**

---

## 3. Command Definitions

`Command Definitions` タブで **読み込み** を押し、Command Definition JSONを選択します。

読み込むと、

- Timelineで選択できるCommand
- 各Commandの引数
- Repositoryタブ

が自動的に構成されます。

画面では各Commandの `Parameter / Type / Description` を確認できます。

---

## 4. Root Directory

`Root Directory` タブで **選択** を押し、TimelineやRepositoryから参照するファイルの基準ディレクトリを指定します。

選択後は、配下のファイル構成をツリーで確認できます。

TimelineやRepositoryに保存されるファイルパスは、Root Directoryからの相対パスです。

例:

```text
Root Directory/
└─ Sound/
   └─ Warning.wav
```

保存される値:

```text
Sound/Warning.wav
```

---

## 5. Repository

Command Definitionで使用されているRepositoryごとにタブが作成されます。

### 読み込み

**読み込み / 再読み込み** からCSVを選択します。

### 編集

Repositoryはデフォルトで編集ロックされています。

編集する場合は、右上の **編集を許可** をONにします。

ONにすると以下が使用できます。

- ID / Pathの編集
- 行の追加
- 行の削除
- Pathのファイル選択
- 保存

IDやPathは **ダブルクリック** で編集できます。

Path右端の `…` ではRoot Directory配下からファイルを選択できます。

### Preview

行を選択すると、Pathで指定された画像または音声を右側でプレビューできます。

---

## 6. Timeline

### 行の追加

**追加** を押すと行を追加します。

行を選択している場合、新しい行は選択行の直後に追加され、Timeは選択行から引き継がれます。

### 行の操作

- **複製**: 選択行を複製
- **↑ / ↓**: 選択行を移動
- 左端のゴミ箱: 行を削除

### Command

CommandセルからCommandを選択します。

Commandを選択すると、そのCommandに必要な引数欄が表示されます。Command Definitionに `defaultValue` がある場合は初期値として入力されます。

### 引数

引数の種類に応じて入力UIが変わります。

- `string`: テキスト入力
- `int / float`: 数値入力
- `bool`: チェックボックス
- `enum`: 選択
- `source`: Repository IDから選択
- `filePath: true`: Root Directory配下のファイルを選択
- `execution`: Commandを選択

`nullable: true` の引数のみ空欄を許可します。それ以外は未入力エラーになります。

---

## 7. Timeline JSONの読み込み

Timelineタブの **読み込み** から既存のTimeline JSONを選択します。

読み込み後、ファイル名と行数が画面上部に表示されます。

---

## 8. 検証

**検証** を押すとTimeline全体をチェックします。

主なエラー:

- Command未選択
- 必須引数の未入力
- Repository IDが存在しない
- 数値範囲外
- ファイルパス未入力

各行の `Status` 列でもエラー状態を確認できます。Status列は横スクロールしても右端に固定されます。

---

## 9. 保存

**保存** を押してTimeline JSONを出力します。

以下の場合は保存できません。

- Validation Errorがある
- Timelineに行がない
- Timeが前の行より小さい

Timeは上から昇順になるようにしてください。

---

## 10. 補足

- Timelineの左側にある `削除 / # / Time / Command` は横スクロール時も固定表示されます。
- `Status` は右端に固定表示されます。
- Repositoryの編集ロックは、誤操作防止のためデフォルトでOFFです。
- Root Directoryを変更すると、以降のファイル選択・Previewは新しいRoot Directoryを基準にします。
