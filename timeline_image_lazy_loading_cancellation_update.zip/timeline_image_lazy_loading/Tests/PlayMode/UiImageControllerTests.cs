using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

public sealed class UiImageControllerTests
{
    [UnityTest]
    public IEnumerator LatestRequestWinsEvenWhenPreviousLoadFinishesLast()
    {
        var repository = new ControlledRepository();
        var output = new RecordingOutput();
        using var controller = new UiImageController(repository, output);
        var target = new UiTargetId("MainImage");
        var first = CreateSprite();
        var second = CreateSprite();

        controller.SetImageByPath(target, "Images/first.png");
        controller.SetImageByPath(target, "Images/second.png");
        repository.Complete("Images/second.png", second);
        yield return new WaitUntil(() => ReferenceEquals(output.LastSprite, second));

        repository.Complete("Images/first.png", first);
        yield return null;
        yield return null;
        Assert.AreSame(second, output.LastSprite);

        DestroySprite(first);
        DestroySprite(second);
    }

    [UnityTest]
    public IEnumerator ResetPreventsLateImageFromBeingRendered()
    {
        var repository = new ControlledRepository();
        var output = new RecordingOutput();
        using var controller = new UiImageController(repository, output);
        var sprite = CreateSprite();

        controller.SetImageByPath(new UiTargetId("MainImage"), "Images/late.png");
        controller.InvalidatePending();
        repository.Complete("Images/late.png", sprite);
        yield return null;
        yield return null;
        Assert.IsNull(output.LastSprite);
        DestroySprite(sprite);
    }

    private static Sprite CreateSprite()
    {
        var texture = new Texture2D(2, 2);
        return Sprite.Create(texture, new Rect(0, 0, 2, 2),
            new Vector2(0.5f, 0.5f));
    }

    private static void DestroySprite(Sprite sprite)
    {
        var texture = sprite.texture;
        UnityEngine.Object.Destroy(sprite);
        UnityEngine.Object.Destroy(texture);
    }

    private sealed class RecordingOutput : IUiImageOutput
    {
        public Sprite LastSprite { get; private set; }
        public void SetImage(UiTargetId target, Sprite sprite) => LastSprite = sprite;
    }

    private sealed class ControlledRepository : IImageRepository
    {
        private readonly Dictionary<string, TaskCompletionSource<Sprite>> _pending =
            new Dictionary<string, TaskCompletionSource<Sprite>>();

        public Sprite Get(ImageId id) => throw new NotSupportedException();
        public Task InitializeAsync(CancellationToken cancellationToken) => Task.CompletedTask;

        public Task<Sprite> GetOrLoadByPathAsync(string path)
        {
            var source = new TaskCompletionSource<Sprite>();
            _pending.Add(path, source);
            return source.Task;
        }

        public void Complete(string path, Sprite sprite)
        {
            _pending[path].SetResult(sprite);
        }
    }
}
