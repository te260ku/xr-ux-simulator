using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

public sealed class ImageRepositoryTests
{
    [UnityTest]
    public IEnumerator DuplicateRequestsShareAnInFlightLoad()
    {
        var loader = new DeferredLoader();
        using var repository = CreateRepository(loader);
        var first = repository.GetOrLoadByPathAsync("Images/test.png");
        var second = repository.GetOrLoadByPathAsync("Images/test.png");

        Assert.AreSame(first, second);
        Assert.AreEqual(1, loader.CallCount);

        loader.Complete(CreateSprite());
        yield return new WaitUntil(() => first.IsCompleted && second.IsCompleted);
        Assert.AreSame(first.Result, second.Result);

        var third = repository.GetOrLoadByPathAsync("Images/test.png");
        Assert.IsTrue(third.IsCompletedSuccessfully);
        Assert.AreSame(first.Result, third.Result);
        Assert.AreEqual(1, loader.CallCount);
    }

    [UnityTest]
    public IEnumerator FailedLoadDoesNotPoisonTheCache()
    {
        var loader = new DeferredLoader();
        using var repository = CreateRepository(loader);
        var first = repository.GetOrLoadByPathAsync("Images/test.png");
        loader.Fail(new IOException("Missing file"));
        yield return new WaitUntil(() => first.IsCompleted);
        Assert.IsTrue(first.IsFaulted);
        _ = first.Exception; // Observe expected failure.

        var retry = repository.GetOrLoadByPathAsync("Images/test.png");
        Assert.AreEqual(2, loader.CallCount);
        loader.Complete(CreateSprite());
        yield return new WaitUntil(() => retry.IsCompleted);
        Assert.IsFalse(retry.IsFaulted);
    }

    [UnityTest]
    public IEnumerator DisposeCancelsPendingLoadWithoutFaultingItsTask()
    {
        var loader = new CancellableLoader();
        var repository = CreateRepository(loader);
        var pending = repository.GetOrLoadByPathAsync("Images/pending.png");

        var shutdown = repository.ShutdownAsync();
        yield return new WaitUntil(() => pending.IsCompleted && shutdown.IsCompleted);

        Assert.IsTrue(loader.Cancelled);
        Assert.IsTrue(pending.IsCanceled);
        Assert.IsFalse(pending.IsFaulted);
        Assert.IsTrue(shutdown.IsCompletedSuccessfully);
        Assert.AreSame(shutdown, repository.ShutdownAsync());
    }

    [UnityTest]
    public IEnumerator ShutdownWaitsForLoaderAndDiscardsLateSprite()
    {
        var loader = new DeferredLoader(); // Deliberately ignores cancellation.
        var repository = CreateRepository(loader);
        var pending = repository.GetOrLoadByPathAsync("Images/late.png");

        repository.Dispose();
        var shutdown = repository.ShutdownAsync();
        Assert.IsFalse(shutdown.IsCompleted);

        var sprite = CreateSprite();
        var texture = sprite.texture;
        loader.Complete(sprite);
        yield return new WaitUntil(() => pending.IsCompleted && shutdown.IsCompleted);
        yield return null; // Object.Destroy is deferred until end of frame.

        Assert.IsTrue(pending.IsCanceled);
        Assert.IsTrue(shutdown.IsCompletedSuccessfully);
        Assert.IsTrue(sprite == null);
        Assert.IsTrue(texture == null);
    }

    [UnityTest]
    public IEnumerator CancellationOfInitializeAbortsCurrentLoadAndAllowsRetry()
    {
        var loader = new CancellableLoader();
        using var repository = new ImageRepository(loader, Path.GetTempPath(),
            new Dictionary<string, string> { { "Alert", "Images/alert.png" } });
        using var cancellation = new CancellationTokenSource();
        var initialization = repository.InitializeAsync(cancellation.Token);

        Assert.AreEqual(1, loader.CallCount);
        cancellation.Cancel();
        yield return new WaitUntil(() => initialization.IsCompleted);
        Assert.IsTrue(initialization.IsCanceled);
        Assert.IsTrue(loader.Cancelled);

        var retry = repository.GetOrLoadByPathAsync("Images/alert.png");
        Assert.AreEqual(2, loader.CallCount);
        var sprite = CreateSprite();
        loader.Complete(sprite);
        yield return new WaitUntil(() => retry.IsCompleted);

        Assert.IsTrue(retry.IsCompletedSuccessfully);
        Assert.AreSame(sprite, retry.Result);
    }

    [UnityTest]
    public IEnumerator FailureAfterDisposeIsObservedAndShutdownStillCompletes()
    {
        var loader = new DeferredLoader();
        var repository = CreateRepository(loader);
        var pending = repository.GetOrLoadByPathAsync("Images/fails.png");
        var shutdown = repository.ShutdownAsync();

        loader.Fail(new IOException("disk failure"));
        yield return new WaitUntil(() => pending.IsCompleted && shutdown.IsCompleted);

        Assert.IsTrue(pending.IsFaulted);
        _ = pending.Exception;
        Assert.IsTrue(shutdown.IsCompletedSuccessfully);
    }

    private sealed class CancellableLoader : ISpriteLoader
    {
        private TaskCompletionSource<Sprite> _pending;
        public int CallCount { get; private set; }
        public bool Cancelled { get; private set; }

        public Task<Sprite> LoadAsync(string path, CancellationToken token)
        {
            CallCount++;
            _pending = new TaskCompletionSource<Sprite>(
                TaskCreationOptions.RunContinuationsAsynchronously);
            var source = _pending;
            token.Register(() =>
            {
                Cancelled = true;
                source.TrySetCanceled();
            });
            return source.Task;
        }

        public void Complete(Sprite sprite) => _pending.SetResult(sprite);
    }

    private static ImageRepository CreateRepository(ISpriteLoader loader)
    {
        return new ImageRepository(loader, Path.GetTempPath(),
            new Dictionary<string, string>());
    }

    private static Sprite CreateSprite()
    {
        var texture = new Texture2D(2, 2);
        return Sprite.Create(texture, new Rect(0, 0, 2, 2),
            new Vector2(0.5f, 0.5f));
    }

    private sealed class DeferredLoader : ISpriteLoader
    {
        private TaskCompletionSource<Sprite> _pending;
        public int CallCount { get; private set; }

        public Task<Sprite> LoadAsync(string path, CancellationToken token)
        {
            CallCount++;
            _pending = new TaskCompletionSource<Sprite>();
            return _pending.Task;
        }

        public void Complete(Sprite sprite) => _pending.SetResult(sprite);
        public void Fail(Exception exception) => _pending.SetException(exception);
    }
}
