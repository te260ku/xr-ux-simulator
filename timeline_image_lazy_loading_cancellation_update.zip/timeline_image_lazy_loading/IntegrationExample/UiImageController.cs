using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

// Integration example: merge these methods into the current UI/Image controller.
// Register only one owner for each TimelineCommand ID; avoid duplicate SetImage commands.
public sealed class UiImageController : IDisposable
{
    private readonly IImageRepository _images;
    private readonly IUiImageOutput _output;
    private readonly Dictionary<string, long> _latestByTarget =
        new Dictionary<string, long>(StringComparer.Ordinal);
    private long _nextRequest;
    private bool _disposed;

    public UiImageController(IImageRepository images, IUiImageOutput output)
    {
        _images = images ?? throw new ArgumentNullException(nameof(images));
        _output = output ?? throw new ArgumentNullException(nameof(output));
    }

    [TimelineCommand("SetImageByPath")]
    public void SetImageByPath(UiTargetId target, string path)
    {
        var request = BeginRequest(target);
        _ = ApplyImageAsync(target, path, request);
    }

    // If an existing SetImage command already exists, integrate BeginRequest
    // in that implementation instead of registering a second command.
    [TimelineCommand("SetImage")]
    public void SetImage(UiTargetId target, ImageId id)
    {
        BeginRequest(target);
        _output.SetImage(target, _images.Get(id));
    }

    // Call on timeline Stop / Reset / switch, before releasing UI targets.
    public void InvalidatePending()
    {
        _latestByTarget.Clear();
    }

    // Also call when another UI operation replaces or clears a target image.
    public void InvalidatePending(UiTargetId target)
    {
        BeginRequest(target);
    }

    private long BeginRequest(UiTargetId target)
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(UiImageController));
        if (target == null)
            throw new ArgumentNullException(nameof(target));
        var request = ++_nextRequest;
        _latestByTarget[target.Value] = request;
        return request;
    }

    private bool IsLatest(UiTargetId target, long request)
    {
        return !_disposed &&
            _latestByTarget.TryGetValue(target.Value, out var latest) &&
            latest == request;
    }

    private async Task ApplyImageAsync(
        UiTargetId target, string path, long request)
    {
        try
        {
            var sprite = await _images.GetOrLoadByPathAsync(path);
            if (IsLatest(target, request))
                _output.SetImage(target, sprite);
        }
        catch (OperationCanceledException)
        {
            // Cancellation from repository shutdown is expected.
        }
        catch (Exception exception)
        {
            if (IsLatest(target, request))
                Debug.LogError($"SetImageByPath failed: {path}\n{exception}");
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        InvalidatePending();
        _disposed = true;
    }
}
