using UnityEngine;

// Implement with the existing UI image target registry / UI controller.
public interface IUiImageOutput
{
    void SetImage(UiTargetId target, Sprite sprite);
}
