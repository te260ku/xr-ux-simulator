using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

// Stateless per-operation loader. Cancellation is owned by the ImageRepository.
// Invoke from Unity's main thread and do not use ConfigureAwait(false).
public sealed class SpriteLoader : ISpriteLoader
{
    public async Task<Sprite> LoadAsync(
        string absolutePath, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (!File.Exists(absolutePath))
            throw new FileNotFoundException("Image file not found.", absolutePath);

        using var request = UnityWebRequestTexture.GetTexture(
            new Uri(absolutePath).AbsoluteUri, nonReadable: true);
        var operation = request.SendWebRequest();

        try
        {
            while (!operation.isDone)
            {
                cancellationToken.ThrowIfCancellationRequested();
                await Task.Yield();
            }
            cancellationToken.ThrowIfCancellationRequested();
        }
        catch (OperationCanceledException)
        {
            request.Abort();
            throw;
        }

        if (request.result != UnityWebRequest.Result.Success)
            throw new IOException($"Image load failed: {absolutePath}: {request.error}");

        var texture = DownloadHandlerTexture.GetContent(request);
        if (texture == null)
            throw new InvalidDataException($"Invalid image: {absolutePath}");

        Sprite sprite = null;
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            sprite = Sprite.Create(texture,
                new Rect(0f, 0f, texture.width, texture.height),
                new Vector2(0.5f, 0.5f), 100f);
            if (sprite == null)
                throw new InvalidDataException($"Sprite creation failed: {absolutePath}");
            cancellationToken.ThrowIfCancellationRequested();
            return sprite;
        }
        catch
        {
            if (sprite != null)
                UnityEngine.Object.Destroy(sprite);
            UnityEngine.Object.Destroy(texture);
            throw;
        }
    }
}
