using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

public interface ISpriteLoader
{
    Task<Sprite> LoadAsync(string absolutePath, CancellationToken cancellationToken);
}
