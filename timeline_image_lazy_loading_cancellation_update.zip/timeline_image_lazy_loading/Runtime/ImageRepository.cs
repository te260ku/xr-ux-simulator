using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

// All public methods and loader continuations must execute on Unity's main thread.
// The existing resource-definition CSV parser supplies the ID -> Data-relative path map.
public sealed class ImageRepository : IImageRepository, IDisposable
{
    private readonly ISpriteLoader _loader;
    private readonly string _dataRoot;
    private readonly Dictionary<string, string> _pathsById;
    private readonly Dictionary<string, Sprite> _cache =
        new Dictionary<string, Sprite>(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, Task<Sprite>> _loading =
        new Dictionary<string, Task<Sprite>>(StringComparer.OrdinalIgnoreCase);
    private readonly CancellationTokenSource _shutdown = new CancellationTokenSource();
    private readonly TaskCompletionSource<bool> _shutdownCompleted =
        new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
    private bool _disposed;

    public ImageRepository(
        ISpriteLoader loader,
        string dataRoot,
        IReadOnlyDictionary<string, string> pathsById)
    {
        _loader = loader ?? throw new ArgumentNullException(nameof(loader));
        if (string.IsNullOrWhiteSpace(dataRoot))
            throw new ArgumentException("Data root is required.", nameof(dataRoot));

        _dataRoot = Path.GetFullPath(dataRoot)
            .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
            + Path.DirectorySeparatorChar;
        if (pathsById == null)
            throw new ArgumentNullException(nameof(pathsById));
        _pathsById = new Dictionary<string, string>(pathsById, StringComparer.Ordinal);
    }

    // Must complete before consumers start normal/timeline command execution.
    // Cancellation of initialization also cancels its current underlying image load.
    // Initialization is exclusive; do not run it concurrently with lazy loads.
    public async Task InitializeAsync(CancellationToken cancellationToken)
    {
        ThrowIfDisposed();
        cancellationToken.ThrowIfCancellationRequested();
        foreach (var path in _pathsById.Values)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await GetOrLoadAsync(path, cancellationToken);
        }
    }

    public Sprite Get(ImageId id)
    {
        ThrowIfDisposed();
        if (id == null)
            throw new ArgumentNullException(nameof(id));
        if (!_pathsById.TryGetValue(id.Value, out var path))
            throw new KeyNotFoundException($"Unknown image ID: {id.Value}");

        var key = ResolvePath(path);
        if (_cache.TryGetValue(key, out var sprite))
            return sprite;
        throw new InvalidOperationException($"Image not initialized: {id.Value}");
    }

    public Task<Sprite> GetOrLoadByPathAsync(string relativePath)
    {
        return GetOrLoadAsync(relativePath, CancellationToken.None);
    }

    private Task<Sprite> GetOrLoadAsync(string relativePath, CancellationToken requestToken)
    {
        ThrowIfDisposed();
        requestToken.ThrowIfCancellationRequested();
        var key = ResolvePath(relativePath);
        if (_cache.TryGetValue(key, out var cached))
            return Task.FromResult(cached);
        if (_loading.TryGetValue(key, out var pending))
            return pending;

        var source = new TaskCompletionSource<Sprite>(
            TaskCreationOptions.RunContinuationsAsynchronously);
        _loading.Add(key, source.Task);
        _ = LoadAndCacheAsync(key, requestToken, source);
        return source.Task;
    }

    private async Task LoadAndCacheAsync(
        string key, CancellationToken requestToken, TaskCompletionSource<Sprite> source)
    {
        Sprite sprite = null;
        try
        {
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(
                _shutdown.Token, requestToken);
            sprite = await _loader.LoadAsync(key, linked.Token);
            linked.Token.ThrowIfCancellationRequested();
            if (_disposed)
                throw new OperationCanceledException("Repository is disposed.");
            if (sprite == null)
                throw new InvalidDataException($"Sprite loader returned null: {key}");

            _cache.Add(key, sprite);
            sprite = null; // Cache now owns Sprite and Texture2D.
            source.TrySetResult(_cache[key]);
        }
        catch (OperationCanceledException)
        {
            source.TrySetCanceled();
        }
        catch (Exception error)
        {
            source.TrySetException(error);
        }
        finally
        {
            if (sprite != null)
                DestroySprite(sprite); // Late completion after cancellation.
            _loading.Remove(key);
            CompleteShutdownIfReady();
        }
    }

    private string ResolvePath(string relativePath)
    {
        if (string.IsNullOrWhiteSpace(relativePath) || Path.IsPathRooted(relativePath))
            throw new ArgumentException("Expected a Data-relative path.", nameof(relativePath));

        var fullPath = Path.GetFullPath(Path.Combine(_dataRoot, relativePath));
        if (!fullPath.StartsWith(_dataRoot, StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Image path is outside Data.", nameof(relativePath));
        return fullPath;
    }

    private void ThrowIfDisposed()
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(ImageRepository));
    }

    // Synchronous fallback for VContainer's IDisposable disposal path.
    // It cancels immediately; it cannot wait for async loader continuations.
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _shutdown.Cancel();
        foreach (var sprite in _cache.Values)
            DestroySprite(sprite);
        _cache.Clear();
        CompleteShutdownIfReady();
    }

    // Prefer awaiting this before tearing down Unity's main-thread event loop.
    public Task ShutdownAsync()
    {
        Dispose();
        return _shutdownCompleted.Task;
    }

    private void CompleteShutdownIfReady()
    {
        if (!_disposed || _loading.Count != 0 || _shutdownCompleted.Task.IsCompleted)
            return;
        _shutdown.Dispose();
        _shutdownCompleted.TrySetResult(true);
    }

    private static void DestroySprite(Sprite sprite)
    {
        if (sprite == null) return;
        var texture = sprite.texture;
        UnityEngine.Object.Destroy(sprite);
        if (texture != null)
            UnityEngine.Object.Destroy(texture);
    }
}
