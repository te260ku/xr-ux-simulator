using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

// ImageId is the application's existing value object (with a string Value property).
public interface IImageRepository
{
    Sprite Get(ImageId id);
    Task<Sprite> GetOrLoadByPathAsync(string relativePath);
    Task InitializeAsync(CancellationToken cancellationToken);
}
