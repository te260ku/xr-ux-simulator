# SetImageByPath: Lazy Loading + shutdown/cancellation improvements

Unity 6 / Windows standalone / C# 9.0 向けの **統合用参照実装** です。
既存の ImageRepository、CSV パーサー、UiController、値オブジェクト、VContainer 登録は
提供されていないため、この ZIP をそのまま既存プロジェクトへ上書きしないでください。

## 今回の変更点

1. **SpriteLoader は IDisposable を実装しません。** 画像ロードごとの
   `CancellationToken` に従い、取り込み中の `UnityWebRequest` を `Abort()` します。
2. **ImageRepository がロードの生存期間を所有します。** `Dispose()` で
   進行中ロードにキャンセルを通知します。新規ロードは受け付けません。
3. **`ShutdownAsync()` を追加しました。** `Dispose()` を実行した上で、
   既存の全ロードが実際に終了し、Sprite の後始末が完了するまで待ちます。
4. **キャンセルと失敗を区別します。** キャンセルでは共有 Task は `Canceled`、
   ファイル破損などでは `Faulted` に遷移します。どちらもキャッシュには残しません。
5. **初期化キャンセルを現在のロードまで伝播します。** `InitializeAsync(token)` は
   内部のロード処理に token を渡し、実行途中でも UnityWebRequest を中断できます。
6. **遅延完了を安全に破棄します。** Loader がキャンセルを無視して Sprite を返しても、
   Repository はキャッシュせず、その Sprite / Texture2D を破棄します。
7. **CancellationTokenSource の破棄は最後に行います。** すべての内部ロードが
   終了してから、Repository の `_shutdown` を Dispose します。

## 公開 API と制約

既存 `IImageRepository` の公開 API は変更していません。

```csharp
public interface IImageRepository
{
    Sprite Get(ImageId id);
    Task<Sprite> GetOrLoadByPathAsync(string relativePath);
    Task InitializeAsync(CancellationToken cancellationToken);
}
```

終了処理は具象 `ImageRepository` の `Dispose()` と `ShutdownAsync()` で行います。
`IImageRepository` の利用者（UiController 等）へ終了メソッドを露出させない設計です。

- `InitializeAsync()` は通常/タイムライン操作を開始する**前**に実行してください。
  `InitializeAsync` 中は、それ以外の `GetOrLoadByPathAsync()` を同時実行しないでください。
  初期化のキャンセルトークンは、当該共有ロードの所有者として解釈されます。
- 起動時、リソース定義ファイルに載った ID 指定画像だけを一括ロードします。
- `SetImageByPath` の画像は初回のみロードし、次回以降は同じキャッシュを使用します。
- 同一パスへの同時リクエストは 1 つの Task を共有します。
- Lazy Loading の処理ごとの呼出側キャンセルは提供しません（共有ロードを
  一利用者が打ち切ることで、他の利用者まで巻き込まないため）。
- すべての Repository / Controller の呼出、Loader の開始、および継続は
  Unity のメインスレッドで行ってください。`ConfigureAwait(false)` は使いません。
- Repository に Sprite / Texture2D の所有権があります。表示中の UI がある場合、
  先に UI 側を無効化し、画像への参照を取り除いてから Repository を破棄します。
- Data フォルダ内の信頼できるローカルファイルを前提とします。シンボリックリンクや
  Windows junction の解決を含む厳密なパスセキュリティは対象外です。

## 推奨する終了順序

```csharp
// アプリケーション終了処理の例（メインスレッド上）
// 1. 新規タイムラインコマンドを停止する
// 2. UI の未完了要求を無効化する
uiImageController.InvalidatePending();
// 3. UI が保持している Sprite 参照を解除する
// 4. Repository の終了を待つ
await imageRepository.ShutdownAsync();
// 5. UI 等を破棄し、Unity のイベントループを終了する
```

VContainer の標準的な同期 `Dispose()` だけが呼ばれる場合でも、
進行中ロードへのキャンセル要求と、**後から完了したロードの Sprite 解放**を行います。
ただし、`Dispose()` 単独では完了待ちを保証できません。PlayMode 終了や
アプリ終了直前の確実な完了が必要な場合は、Unity が動作している間に
`ShutdownAsync()` を `await` してください。

`ShutdownAsync()` は、Loader がキャンセル後も完了しない場合には待ち続けます。
実際の `SpriteLoader` は CancellationToken を監視して `UnityWebRequest.Abort()` を
呼び出します。メインスレッドをブロックする `Wait()` / `.Result` で待機しないでください。

## 導入手順

1. 既存のリソース定義ファイル CSV 読み込みはそのまま維持します。
   ID → Data 相対パス辞書を ImageRepository に渡してください。
2. Data ルートの絶対パスは Composition Root で作成して注入します。
3. 既存 `ImageRepository` へ `GetOrLoadByPathAsync()` と、今回の
   Dispose / ShutdownAsync のライフサイクル処理を統合してください。
4. `SpriteLoader` は `ISpriteLoader` として注入します。
5. 現在の UI/Image Controller に `SetImageByPath` と要求番号による
   表示の逆転防止処理を追加します。既存 `SetImage` の二重登録はしません。
6. VContainer に ImageRepository を Singleton として登録します。
   シャットダウンを明示的に呼び出す終了処理には、具象型も解決できるようにしてください。
7. コンパイルし、PlayMode テストと実際のファイル読み込みを検証してください。

## テスト

`Tests/PlayMode/ImageRepositoryTests.cs` に追加した検証:

- Dispose → ロード Task が Faulted ではなく Canceled になる
- ShutdownAsync → 実ロード終了まで待機する
- キャンセルを無視した Loader の遅延 Sprite を解放する
- InitializeAsync のキャンセル → 進行中ロード中断、次回再試行可能
- Dispose 後のロード失敗 → ShutdownAsync は完了する

既存の重複ロード共有、失敗後再試行、表示順序逆転防止テストも保持しています。

**重要:** Unity Editor 上のコンパイル／PlayMode 実行はこの環境ではできていません。
既存の `ImageId`、`UiTargetId`、`TimelineCommandAttribute`、UI 実装に合わせる必要があります。
