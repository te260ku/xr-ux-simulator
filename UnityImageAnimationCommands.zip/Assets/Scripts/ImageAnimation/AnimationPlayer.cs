using System;
using UnityEngine;
using UnityEngine.Playables;

public sealed class AnimationPlayer : IDisposable
{
    private readonly Animator _animator;
    private PlayableGraph _graph;

    public AnimationPlayer(Animator animator)
    {
        _animator = animator ?? throw new ArgumentNullException(nameof(animator));
    }

    public void Play(AnimationClip clip, float duration)
    {
        if (clip == null || clip.length <= 0f ||
            !(duration > 0f) || float.IsInfinity(duration))
        {
            Debug.LogError("Invalid animation parameters.");
            return;
        }

        Dispose();

        var playable = AnimationPlayableUtilities.PlayClip(
            _animator, clip, out _graph);

        playable.SetSpeed(clip.length / duration);
    }

    public void Dispose()
    {
        if (_graph.IsValid())
            _graph.Destroy();
    }
}
