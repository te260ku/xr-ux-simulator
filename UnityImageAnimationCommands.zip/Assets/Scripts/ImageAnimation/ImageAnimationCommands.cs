using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public sealed class ImageAnimationBinding
{
    [SerializeField] private string _id;
    [SerializeField] private Animator _fadeAnimator;
    [SerializeField] private Animator _scaleAnimator;

    public string Id => _id;
    public Animator FadeAnimator => _fadeAnimator;
    public Animator ScaleAnimator => _scaleAnimator;
}

public sealed class ImageAnimationCommands : MonoBehaviour
{
    [Header("Animation Targets")]
    [SerializeField]
    private List<ImageAnimationBinding> _bindings = new();

    [Header("Animation Clips")]
    [SerializeField] private AnimationClip _fadeIn;
    [SerializeField] private AnimationClip _fadeOut;
    [SerializeField] private AnimationClip _scaleUp;
    [SerializeField] private AnimationClip _scaleDown;

    private readonly Dictionary<string, AnimationPlayer> _fadePlayers = new();
    private readonly Dictionary<string, AnimationPlayer> _scalePlayers = new();

    private void Awake()
    {
        foreach (var binding in _bindings)
        {
            if (binding == null || string.IsNullOrWhiteSpace(binding.Id))
            {
                Debug.LogError("Invalid image animation target.");
                continue;
            }

            if (_fadePlayers.ContainsKey(binding.Id) ||
                _scalePlayers.ContainsKey(binding.Id))
            {
                Debug.LogError($"Duplicate animation target: {binding.Id}");
                continue;
            }

            if (binding.FadeAnimator != null)
                _fadePlayers.Add(binding.Id,
                    new AnimationPlayer(binding.FadeAnimator));

            if (binding.ScaleAnimator != null)
                _scalePlayers.Add(binding.Id,
                    new AnimationPlayer(binding.ScaleAnimator));
        }
    }

    [TimelineCommand("FadeInImage")]
    public void FadeInImage(ImageAnimationTargetId targetId, float duration)
    {
        Play(_fadePlayers, targetId, _fadeIn, duration);
    }

    [TimelineCommand("FadeOutImage")]
    public void FadeOutImage(ImageAnimationTargetId targetId, float duration)
    {
        Play(_fadePlayers, targetId, _fadeOut, duration);
    }

    [TimelineCommand("ScaleUpImage")]
    public void ScaleUpImage(ImageAnimationTargetId targetId, float duration)
    {
        Play(_scalePlayers, targetId, _scaleUp, duration);
    }

    [TimelineCommand("ScaleDownImage")]
    public void ScaleDownImage(ImageAnimationTargetId targetId, float duration)
    {
        Play(_scalePlayers, targetId, _scaleDown, duration);
    }

    private void Play(
        Dictionary<string, AnimationPlayer> players,
        ImageAnimationTargetId targetId,
        AnimationClip clip,
        float duration)
    {
        if (targetId == null ||
            !players.TryGetValue(targetId.Value, out var player))
        {
            Debug.LogError("Animation target not found.");
            return;
        }

        player.Play(clip, duration);
    }

    private void OnDestroy()
    {
        foreach (var player in _fadePlayers.Values)
            player.Dispose();

        foreach (var player in _scalePlayers.Values)
            player.Dispose();
    }
}
