public sealed class ImageAnimationTargetId : IRepositoryKey
{
    public string Value { get; }

    public ImageAnimationTargetId(string value)
    {
        Value = value;
    }
}
