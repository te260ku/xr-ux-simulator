# Position連携機能 概要設計書

## 1. 目的・前提

- **目的**：Unity内のC#ライブラリから最新座標を取得し、共通座標へ変換して、UI表示と別のC#ライブラリを通じた外部出力に利用する。UI操作からも外部出力を制御できるようにする。
- **方式**：座標入力は毎フレームのポーリング。採用するのは**案B（PositionUpdater → PositionCoordinator）**。
- **アーキテクチャ**：全体は **Hexagonal Architecture（Ports & Adapters）**、UI内部は必要最小限の **MVP** を適用する。
- **実装方針**：Coordinator、Model、Converter、PresenterはPure C#。UnityのライフサイクルとUI実装はアダプタ側に閉じ込める。
- **配置**：入力・出力のC#ライブラリがUnityプロジェクト内に存在しても、Coreとの**論理的な境界**で役割を分類する。

## 2. 全体構成

- **Driving Adapter**：`PositionUpdater`が`ITickable.Tick()`で入力C#ライブラリをポーリングし、取得値をCoordinatorに渡す。
- **Driving Port**：`PositionCoordinator.UpdatePosition(...)`など、Coordinatorが公開するユースケースAPI。**入力ポート専用interfaceは必須ではない**。
- **Application Core**：Coordinatorが座標変換、Model更新、外部出力を協調する。Modelが変換後座標を保持する。
- **Driven Port**：`IPositionController`が外部制御の契約を定義する。
- **Driven Adapter**：`PositionController`が出力C#ライブラリのAPIに適合させる。
- **UI Adapter**：`PositionPresenter`と`PositionView`で構成する。PresenterはModelを購読し、View操作をCoordinatorに伝える。

## 3. クラス図（PlantUML）

```plantuml
@startuml
left to right direction
skinparam classAttributeIconSize 0

package "Input Adapter" {
  class PositionUpdater <<Driving Adapter, ITickable>> {
    +Tick(): void
  }
  class PositionCsLibrary <<C# Library>>
}

package "Application Core" {
  class PositionCoordinator {
    +UpdatePosition(raw: RawPosition): void
    +RequestReset(): void
  }
  class PositionConverter {
    +Convert(raw: RawPosition): Position
  }
  class PositionModel {
    +CurrentPosition: Position
    +PositionChanged: Observable~Position~
    +Update(position: Position): void
  }
  interface IPositionController <<Driven Port>> {
    +Send(position: Position): void
    +Reset(): void
  }
  class RawPosition <<Input Data>>
  class Position <<Value Object>>
}

package "UI Adapter (MVP)" {
  class PositionPresenter {
    +OnResetRequested(): void
  }
  interface IPositionView {
    +ShowPosition(position: Position): void
    +ResetRequested: event
  }
  class PositionView <<MonoBehaviour>>
}

package "Output Adapter" {
  class PositionController <<Driven Adapter>>
  class OutputCsLibrary <<C# Library>>
}

PositionUpdater --> PositionCsLibrary : Poll
PositionUpdater --> PositionCoordinator : UpdatePosition(raw)\nDriving Port
PositionCoordinator --> PositionConverter : Convert
PositionCoordinator --> PositionModel : Update
PositionCoordinator --> IPositionController : Send / Reset
PositionController ..|> IPositionController
PositionController --> OutputCsLibrary : Call API
PositionPresenter --> PositionModel : Subscribe (R3)
PositionPresenter --> PositionCoordinator : RequestReset()\nDriving Port
PositionPresenter --> IPositionView : Display / Receive input
PositionView ..|> IPositionView

note bottom of PositionCoordinator
  公開ユースケースAPIが入力Port。
  interfaceを必須とはしない。
end note
note bottom of PositionPresenter
  RequestReset / Reset はUI操作の例。
  実際の操作要件に合わせて命名する。
end note
@enduml
```

**図の矢印は主にコード上の依存・呼び出しを表す。** ModelはPresenterの存在を知らない。Presenter側がModelのObservableを購読する。

## 4. コンポーネント責務

| コンポーネント | 位置付け | 主な責務 |
|---|---|---|
| `PositionUpdater` | Driving Adapter | `ITickable`で最新座標をポーリングし、Coreで定義した入力データに適合させ、Coordinatorへ渡す。 |
| `PositionCsLibrary` | 入力側ライブラリ | 最新座標を取得するAPIを提供する。アダプタが利用する実装詳細。 |
| `PositionCoordinator` | Core／入力Portの公開主体 | 座標更新・UI操作に関するユースケースを受け、変換・Model更新・外部制御を協調する。 |
| `PositionConverter` | Core | 入力座標をViewと外部出力が共有する座標系へ変換する。 |
| `PositionModel` | Core | 変換後の最新座標を保持し、R3で状態変更を通知する。 |
| `PositionPresenter` | UI Adapter（MVP） | Modelの変更購読、View向け表示処理、View操作のCoordinatorへの委譲を担う。 |
| `IPositionView` | UI内部の契約 | Presenterが必要とする表示操作とUIイベントを定義する。Hexagonal ArchitectureのPortではない。 |
| `PositionView` | UI Adapter（MVP） | uGUIなどで画面表示・ユーザー操作の検知を実装する。 |
| `IPositionController` | Driven Port | 外部出力・制御に必要な操作をCore側の型で定義する。 |
| `PositionController` | Driven Adapter | 出力C#ライブラリのAPIを呼び出し、必要なら機器固有形式に変換する。 |
| `OutputCsLibrary` | 出力側ライブラリ | 外部システムへ座標・操作指示を送るAPIを提供する。 |

## 5. 主要な処理フロー

### 5.1 自動座標更新（ポーリング）

1. VContainerの`ITickable`から`PositionUpdater.Tick()`を毎フレーム実行する。
2. Updaterが入力C#ライブラリの最新座標を取得する。有効なデータがない場合の扱いは取得APIの契約に従う。
3. Updaterが`PositionCoordinator.UpdatePosition(raw)`を呼び出す。
4. Coordinatorが`PositionConverter`を呼び、**共通座標を1回生成**する。
5. Coordinatorがその座標で`PositionModel`を更新し、同じ座標を`IPositionController.Send(...)`に渡す。
6. PresenterがModelの変更を購読して`IPositionView`を更新する。

### 5.2 Viewからの操作

1. Viewが操作イベントを発行する。
2. Presenterが対応するCoordinatorの**入力Port**（例：`RequestReset()`）を呼び出す。
3. Coordinatorが必要な条件を判断し、`IPositionController`へ操作を依頼する。
4. **操作指示を伝えるためだけにModelを経由しない。** 操作によって管理すべき状態が変わる場合に限りModelも更新する。

## 6. 設計ルール

- **依存方向**：Updater・Presenter・ControllerなどのAdapterはCoreが公開／要求するAPIに依存する。CoreはUnityの`MonoBehaviour`、`ITickable`、uGUI、外部C#ライブラリの具体型に依存しない。
- **入力Port**：Coordinatorの公開ユースケースメソッドで実現する。差し替えが必要にならなければ専用interfaceを増やさない。
- **出力Port**：`IPositionController`をCore側で定義し、具体的な`PositionController`が実装する。
- **状態と命令の分離**：Modelは状態管理用。操作命令の中継装置として使用しない。
- **座標変換**：共通変換はConverter、表示固有の変換はPresenter、出力先固有の変換はControllerに置く。
- **UI**：Presenterにテストすべき表示／入力ロジックがある場合に`IPositionView`を使う。単純なUIにはPresenterを機械的に追加しない。
- **起動機構**：`AppUpdater`が単に中継するだけなら設けず、`PositionUpdater`自身に`ITickable`を実装する。

## 7. 実装前に確定する事項

| 項目 | 確認内容 |
|---|---|
| 送信周期 | 毎フレーム送信か、変更時のみか、一定周期か。 |
| データ有効性 | 初期値、未取得、取得失敗、古いデータをどう区別するか。 |
| 通信の実行方式 | 出力ライブラリの呼び出しがブロッキングする場合のメインスレッド対策。 |
| 制御の競合 | 自動出力とViewからの手動操作が競合する場合の優先規則。 |
| 失敗時の状態 | Modelが保持する位置と、外部への送信成功・実機反映状態を区別する必要があるか。 |
| UI操作 | `RequestReset()`／`Reset()`は例示。実際の操作に合わせてPortを決定する。 |

## 8. テスト方針

- **Coordinator**：座標入力に対する変換結果、Model更新、Controller呼び出しをFakeで検証する。
- **Converter**：座標系、単位、境界値の変換を純粋な単体テストで検証する。
- **Presenter**：Fakeの`IPositionView`を使って表示反映とユーザー操作の委譲を検証する。
- **Updater／Controller**：各C#ライブラリとの接続、取得失敗や通信エラーを統合テストで検証する。

**設計判断**：全体は案BのPorts & Adaptersを採用し、UIに必要な範囲だけMVPを適用する。入力側の追加Receiver、単なる中継Service、不要なinterfaceは設けない。
